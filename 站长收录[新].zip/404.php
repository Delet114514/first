<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 - 文件或目录不存在</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: system-ui,sans-serif;
            background:#111827;
            color:#cbd5e1;
            min-height:100vh;
            display:flex;
            align-items:center;
            justify-content:center;
            padding:20px;
        }
        .wrap{
            text-align:center;
        }
        .num{
            font-size:110px;
            font-weight:bold;
            color:#60a5fa;
        }
        h2{
            font-size:24px;
            margin:10px 0;
        }
        p{
            color:#94a3b8;
            margin-bottom:30px;
        }
        a{
            padding:11px 28px;
            background:#3b82f6;
            color:#fff;
            text-decoration:none;
            border-radius:6px;
        }
        a:hover{
            background:#2563eb;
        }
        @media(max-width:550px){
            .num{font-size:75px;}
        }
    </style>
</head>
<body>
<div class="wrap">
    <div class="num">404</div>
    <h2>您访问的文件或目录不存在</h2>
    <p>链接错误、资源已删除或者文件已经被移动，请核对地址。</p>
    <a href="./">返回首页</a>
</div>
</body>
</html>
