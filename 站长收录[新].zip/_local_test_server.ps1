﻿# 欢欢云导航 - 本地测试服务器 v2（C# 内核异步高并发）
# 解决 v1 单线程同步 GetContext 的并发问题 → 所有 fetch 同时发时不再 ERR_CONNECTION_REFUSED
# 启动: powershell -ExecutionPolicy Bypass -File "d:\桌面\网站项目\收录\_local_test_server.ps1"
param([int]$Port = 5173)

$ErrorActionPreference = 'Stop'

$ROOT     = 'd:\桌面\网站项目\收录'
$DATA_DIR = Join-Path $ROOT 'data'

# 每次调用都写回 BOM，避免编码问题
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Web;
using System.Web.Script.Serialization;

namespace HhNavLocalServer {
    public static class Program {
        static readonly string ROOT     = @"$($ROOT)";
        static readonly string DATA_DIR = @"$($DATA_DIR)";
        static readonly string USERS_FILE    = System.IO.Path.Combine(DATA_DIR, "users.json");
        static readonly string SESSIONS_FILE = System.IO.Path.Combine(DATA_DIR, "sessions.json");
        static readonly string SUBMISS_FILE  = System.IO.Path.Combine(DATA_DIR, "submissions.json");
        static readonly string SITE_DATA_FILE = System.IO.Path.Combine(DATA_DIR, "site_data.json");
        const string ADMIN_TOKEN_MD5 = "8c87e31b2ebd6e399a0319d2a1389ea6";
        const string PW_SALT = "hh_salt_2026";
        static readonly object FileLock = new object();
        static readonly Dictionary<string, CodeEntry> PendingCodes = new Dictionary<string, CodeEntry>();
        static readonly JavaScriptSerializer Js = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
        static readonly HashSet<string> ValidCats = new HashSet<string>(new []{"pay","server","dist","nav","login","blog","card","tool"});
        static readonly Dictionary<string, string> MIME = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase) {
            {".html","text/html; charset=utf-8"},{".htm","text/html; charset=utf-8"},
            {".css","text/css; charset=utf-8"},{".js","application/javascript; charset=utf-8"},
            {".json","application/json; charset=utf-8"},
            {".svg","image/svg+xml"},{".png","image/png"},{".jpg","image/jpeg"},{".jpeg","image/jpeg"},
            {".gif","image/gif"},{".webp","image/webp"},{".ico","image/x-icon"},
            {".woff","font/woff"},{".woff2","font/woff2"},{".ttf","font/ttf"},
            {".php","text/plain; charset=utf-8"}
        };
        class CodeEntry { public string Code; public DateTime Expire; }

        static string Md5Hex(string s) { using(var m = System.Security.Cryptography.MD5.Create()){ var b = m.ComputeHash(Encoding.UTF8.GetBytes(s)); var sb = new StringBuilder(b.Length*2); foreach(var x in b) sb.Append(x.ToString("x2")); return sb.ToString(); } }
        static string HashPw(string p){ return Md5Hex(p + PW_SALT); }
        static string GenId(){ return DateTime.Now.ToString("yyyyMMddHHmmss") + new Random().Next(0,999).ToString("D3"); }
        static string TimeStr(){ return DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"); }

        static object ReadJson(string p) {
            lock(FileLock){
                try {
                    if(!File.Exists(p)) return null;
                    var raw = File.ReadAllText(p, Encoding.UTF8);
                    if(string.IsNullOrWhiteSpace(raw)) return null;
                    return Js.DeserializeObject(raw);
                } catch (Exception e) {
                    Console.Error.WriteLine("[ReadJson 损坏] " + p + " -> " + e.Message);
                    return null;
                }
            }
        }
        static void WriteJson(string p, object d) {
            lock(FileLock){
                var s = Js.Serialize(d);
                var dir = Path.GetDirectoryName(p);
                if(!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                    Directory.CreateDirectory(dir);
                // 清理只读属性（兼容Windows只读）
                if(File.Exists(p)){
                    var fi = new FileInfo(p);
                    if((fi.Attributes & FileAttributes.ReadOnly) != 0)
                        fi.Attributes = fi.Attributes & ~FileAttributes.ReadOnly;
                }
                // 临时文件+原子替换（保证永不半写损坏）
                var tmp = Path.Combine(dir ?? ".", "." + Path.GetFileName(p) + ".tmp."
                    + Guid.NewGuid().ToString("N") + ".part");
                using(var fs = new FileStream(tmp, FileMode.CreateNew, FileAccess.Write,
                    FileShare.None, 4096, FileOptions.WriteThrough)) {
                    var b = new UTF8Encoding(false).GetBytes(s);
                    fs.Write(b, 0, b.Length);
                    fs.Flush(true);
                }
                try {
                    if(File.Exists(p)) File.Replace(tmp, p, null);
                    else File.Move(tmp, p);
                } catch {
                    // fallback
                    try { if(File.Exists(p)) File.Delete(p); } catch {}
                    File.Move(tmp, p);
                }
            }
        }
        static List<object> ToArray(object o) {
            if(o == null) return new List<object>();
            var l = o as List<object>;
            if(l != null) return l;
            var a = o as object[];
            if(a != null) return new List<object>(a);
            // 单个字典 -> 包成单元素 list
            return new List<object>{ o };
        }
        static string Str(object o){ return o == null ? "" : Convert.ToString(o); }
        static bool IsTruthy(object o){
            if(o == null) return false;
            if(o is bool) return (bool)o;
            var s = o as string; if(s != null){ var ss = s.Trim(); return ss.Length > 0 && ss != "0" && ss != "false" && ss != "False" && ss != "FALSE"; }
            try { if(Convert.ToInt32(o) == 0) return false; } catch{}
            return true;
        }

        static void WriteJsonResp(HttpListenerResponse resp, int code, object obj) {
            resp.StatusCode = code;
            resp.ContentType = "application/json; charset=utf-8";
            resp.AddHeader("Access-Control-Allow-Origin", "*");
            var body = Encoding.UTF8.GetBytes(Js.Serialize(obj));
            resp.ContentLength64 = body.Length;
            resp.OutputStream.Write(body, 0, body.Length);
            resp.OutputStream.Close();
        }

        static object ReadBody(HttpListenerRequest req) {
            try {
                using(var ms = new MemoryStream()) {
                    req.InputStream.CopyTo(ms);
                    var raw = Encoding.UTF8.GetString(ms.ToArray());
                    if(string.IsNullOrWhiteSpace(raw)) return new Dictionary<string, object>();
                    var o = Js.DeserializeObject(raw);
                    if(o == null) return new Dictionary<string, object>();
                    return o;
                }
            } catch { return new Dictionary<string, object>(); }
        }
        static T Get<T>(object input, string key) {
            var d = input as Dictionary<string, object>;
            if(d == null) return default(T);
            if(!d.ContainsKey(key)) return default(T);
            try { return (T)Convert.ChangeType(d[key], typeof(T)); }
            catch { return default(T); }
        }
        static string GetCodeFromServerLog() { /* not used; captcha is printed separately */ return ""; }

        static Dictionary<string,object> Ok(object d=null, string msg=null) {
            var r = new Dictionary<string,object>{{"ok", true}};
            if(msg != null) r["msg"] = msg;
            if(d   != null) r["data"] = d;
            return r;
        }
        static Dictionary<string,object> Err(string msg) { return new Dictionary<string,object>{{"ok", false}, {"msg", msg}}; }

        // ================== 核心 API 分发 ==================
        static object HandleApi(string action, object input) {
            switch(action) {
            case "send_code": {
                var email = Get<string>(input, "email");
                if(string.IsNullOrWhiteSpace(email) || !email.Contains("@")) return Err("邮箱格式不正确");
                var code = new Random().Next(100000, 999999).ToString();
                lock(PendingCodes){ PendingCodes[email] = new CodeEntry{ Code=code, Expire=DateTime.Now.AddMinutes(5) }; }
                Console.WriteLine("\n╔════【本地测试】邮件验证码════╗"
                  + "\n║ 收件人: " + email
                  + "\n║ 验证码: " + code + "  (5 分钟有效)"
                  + "\n╚═══════════════════════════════════╝\n");
                return Ok(msg: "【本地调试无需真实邮件】验证码: "+code);
            }
            case "register": {
                var email=Get<string>(input,"email"); var code=Get<string>(input,"code"); var password=Get<string>(input,"password");
                if(string.IsNullOrWhiteSpace(email)||string.IsNullOrWhiteSpace(code)||string.IsNullOrWhiteSpace(password)) return Err("请填写完整信息");
                CodeEntry entry; lock(PendingCodes){ PendingCodes.TryGetValue(email, out entry); }
                if(entry == null || entry.Code != code || DateTime.Now > entry.Expire) return Err("验证码不正确或已过期");
                var users = ToArray(ReadJson(USERS_FILE));
                foreach(var u_ in users) {
                    var u = u_ as Dictionary<string,object>;
                    if(u != null && Get<string>(u, "email") == email) return Err("该邮箱已注册");
                }
                users.Add(new Dictionary<string,object>{
                    {"id", GenId()}, {"email", email}, {"password", HashPw(password)}, {"register_time", TimeStr()}
                });
                WriteJson(USERS_FILE, users);
                lock(PendingCodes){ PendingCodes.Remove(email); }
                Console.WriteLine("✅ 用户注册: " + email);
                return Ok(msg: "注册成功");
            }
            case "login": {
                var email=Get<string>(input,"email"); var password=Get<string>(input,"password");
                var users = ToArray(ReadJson(USERS_FILE));
                Dictionary<string,object> me = null;
                foreach(var u_ in users) {
                    var u = u_ as Dictionary<string,object>;
                    if(u!=null && Get<string>(u,"email")==email){ me = u; break; }
                }
                if(me==null || HashPw(password) != Get<string>(me,"password")) return Err("邮箱或密码错误");
                var token = Md5Hex(email + DateTime.Now.Ticks + new Random().Next());
                var sessions = ReadJson(SESSIONS_FILE);
                var sMap = sessions as Dictionary<string,object>;
                if(sMap == null) sMap = new Dictionary<string,object>();
                var now = (int)(DateTimeOffset.UtcNow - new DateTimeOffset(1970,1,1,0,0,0,TimeSpan.Zero)).TotalSeconds;
                sMap[token] = new Dictionary<string,object>{
                    {"email", email}, {"user_id", Get<string>(me,"id")},
                    {"login_time", now}, {"expire", now + 86400*7}
                };
                WriteJson(SESSIONS_FILE, sMap);
                Console.WriteLine("✅ 用户登录: " + email + " (token=" + token.Substring(0,8) + "...)");
                return Ok(new Dictionary<string,object>{{"token", token}, {"email", email}}, "登录成功");
            }
            case "check_login": {
                var token = Get<string>(input, "token");
                var sMap = ReadJson(SESSIONS_FILE) as Dictionary<string,object>;
                if(sMap == null) return Err("未登录或登录已过期");
                object v; if(!sMap.TryGetValue(token, out v) || v == null) return Err("未登录或登录已过期");
                var s = v as Dictionary<string,object>;
                if(s == null) return Err("未登录或登录已过期");
                var expire = Convert.ToInt64(s["expire"]);
                var now = (long)(DateTimeOffset.UtcNow - new DateTimeOffset(1970,1,1,0,0,0,TimeSpan.Zero)).TotalSeconds;
                if(now > expire) return Err("未登录或登录已过期");
                return Ok(new Dictionary<string,object>{{"email", Get<string>(s,"email")}});
            }
            case "logout": {
                var token = Get<string>(input,"token");
                var sMap = ReadJson(SESSIONS_FILE) as Dictionary<string,object>;
                if(sMap != null){ sMap.Remove(token); WriteJson(SESSIONS_FILE, sMap); }
                return Ok(msg: "已退出登录");
            }
            case "submit_site": {
                var token = Get<string>(input,"token");
                var sMap = ReadJson(SESSIONS_FILE) as Dictionary<string,object>;
                if(sMap == null) return Err("请先登录后再提交");
                object v; string userEmail = null;
                if(sMap.TryGetValue(token, out v) && v is Dictionary<string,object>) {
                    Dictionary<string,object> s = (Dictionary<string,object>) v;
                    var exp = Convert.ToInt64(s["expire"]);
                    var now = (long)(DateTimeOffset.UtcNow - new DateTimeOffset(1970,1,1,0,0,0,TimeSpan.Zero)).TotalSeconds;
                    if(now < exp) userEmail = Get<string>(s,"email");
                }
                if(userEmail == null) return Err("请先登录后再提交");

                var siteName=Get<string>(input,"site_name"); if(siteName!=null) siteName = siteName.Trim();
                var siteUrl =Get<string>(input,"site_url");  if(siteUrl!=null) siteUrl = siteUrl.Trim();
                var siteDesc=Get<string>(input,"site_desc"); if(siteDesc!=null) siteDesc = siteDesc.Trim();
                var category=Get<string>(input,"category");  if(category!=null) category = category.Trim();
                var contact =Get<string>(input,"contact");   if(contact!=null) contact = contact.Trim();
                if(string.IsNullOrWhiteSpace(siteName)||string.IsNullOrWhiteSpace(siteUrl)||string.IsNullOrWhiteSpace(siteDesc)||string.IsNullOrWhiteSpace(category))
                    return Err("请填写完整信息");
                if(!ValidCats.Contains(category)) return Err("分类不正确");

                var list = ToArray(ReadJson(SUBMISS_FILE));
                var newSub = new Dictionary<string,object>{
                    {"id", GenId()}, {"user_email", userEmail}, {"site_name", siteName}, {"site_url", siteUrl},
                    {"site_desc", siteDesc}, {"category", category}, {"contact", contact},
                    {"status", "pending"}, {"submit_time", TimeStr()}, {"audit_time", ""}, {"audit_remark", ""}
                };
                list.Add(newSub);
                WriteJson(SUBMISS_FILE, list);
                Console.WriteLine("\n╔════【收录提交通知】════╗"
                  + "\n║ 新待审核收录 ID=" + newSub["id"]
                  + "\n║ 站点: " + siteName
                  + "\n║ URL : " + siteUrl
                  + "\n║ 分类: " + category
                  + "\n║ 提交人: " + userEmail
                  + "\n╚════════════════════════════╝\n");
                return Ok(new Dictionary<string,object>{{"id", newSub["id"]}}, "提交成功！您的网站正在等待审核，审核通过后将在首页展示");
            }
            case "admin_submissions": {
                if(Get<string>(input,"admin_token") != ADMIN_TOKEN_MD5) return Err("无权限");
                var list = ToArray(ReadJson(SUBMISS_FILE));
                var st = Get<string>(input,"status");
                if(!string.IsNullOrEmpty(st) && st != "all") {
                    list = list.FindAll(o => { var d = o as Dictionary<string,object>; return d != null && Get<string>(d, "status") == st; });
                }
                list.Sort((a,b) => {
                    var x = a as Dictionary<string,object>; var y = b as Dictionary<string,object>;
                    return string.Compare(Get<string>(y,"submit_time"), Get<string>(x,"submit_time"), StringComparison.Ordinal);
                });
                return Ok(list);
            }
            case "audit_site": {
                if(Get<string>(input,"admin_token") != ADMIN_TOKEN_MD5) return Err("无权限");
                var id = Get<string>(input,"id"); var ast = Get<string>(input,"audit_status"); var remark = Get<string>(input,"audit_remark");
                if(ast != "approved" && ast != "rejected") return Err("审核状态不正确");
                var list = ToArray(ReadJson(SUBMISS_FILE));
                bool found = false;
                foreach(var o in list) {
                    var d = o as Dictionary<string,object>;
                    if(d != null && Get<string>(d,"id") == id) {
                        d["status"] = ast; d["audit_time"] = TimeStr(); d["audit_remark"] = remark ?? ""; found = true; break;
                    }
                }
                if(!found) return Err("记录不存在");
                WriteJson(SUBMISS_FILE, list);
                return Ok(msg: ast == "approved" ? "已审核通过，该网站将展示在前台" : "已拒绝该收录申请");
            }
            case "admin_delete_submission": {
                if(Get<string>(input,"admin_token") != ADMIN_TOKEN_MD5) return Err("无权限");
                var id = Get<string>(input,"id");
                var list = ToArray(ReadJson(SUBMISS_FILE));
                list.RemoveAll(o => { var d = o as Dictionary<string,object>; return d != null && Get<string>(d,"id") == id; });
                WriteJson(SUBMISS_FILE, list);
                return Ok(msg: "已删除");
            }
            case "admin_stats": {
                if(Get<string>(input,"admin_token") != ADMIN_TOKEN_MD5) return Err("无权限");
                var users = ToArray(ReadJson(USERS_FILE));
                var subs  = ToArray(ReadJson(SUBMISS_FILE));
                int pc=0,ac=0,rc=0;
                foreach(var o in subs) {
                    var s = o as Dictionary<string,object>; if(s==null) continue;
                    var st = Get<string>(s,"status");
                    if(st == "pending") pc++;
                    else if(st == "approved") ac++;
                    else if(st == "rejected") rc++;
                }
                return Ok(new Dictionary<string,object>{
                    {"users", users.Count}, {"submissions", subs.Count},
                    {"pending", pc}, {"approved", ac}, {"rejected", rc}
                });
            }
            case "approved_sites": {
                var subs = ToArray(ReadJson(SUBMISS_FILE));
                var list = new List<object>();
                foreach(var o in subs) {
                    var s = o as Dictionary<string,object>;
                    if(s!=null && Get<string>(s,"status") == "approved" && !IsTruthy(Get<object>(s,"hidden"))) {
                        list.Add(new Dictionary<string,object>{
                            {"name", Get<string>(s,"site_name")}, {"desc", Get<string>(s,"site_desc")},
                            {"link", Get<string>(s,"site_url")}, {"category", Get<string>(s,"category")}
                        });
                    }
                }
                return Ok(list);
            }
            case "get_category_links": {
                string category = Get<string>(input,"category") ?? "";
                var validCats = new HashSet<string>(new []{"pay","server","dist","nav","login","blog","card","tool"});
                var sdRaw = ReadJson(SITE_DATA_FILE);
                var sd = sdRaw as Dictionary<string,object>;
                Dictionary<string,object> cats = null;
                if(sd != null && sd.ContainsKey("categories")) cats = sd["categories"] as Dictionary<string,object>;
                if(cats == null) cats = new Dictionary<string,object>();
                var subs = ToArray(ReadJson(SUBMISS_FILE));

                Func<string,List<object>> build = cat => {
                    var customArr = cats.ContainsKey(cat) ? ToArray(cats[cat]) : new List<object>();
                    var list = new List<object>();
                    int maxSort = 0;
                    foreach(var co in customArr) {
                        var c = co as Dictionary<string,object>; if(c == null) continue;
                        int sort = 0; try{ sort = Convert.ToInt32(Get<object>(c,"sort")); } catch{}
                        if(sort > maxSort) maxSort = sort;
                        string idStr;
                        try { idStr = Convert.ToString(Get<object>(c,"id")); } catch { idStr = ""; }
                        if(string.IsNullOrEmpty(idStr)){
                            var baseKey = (Get<string>(c,"name") ?? "") + "|" + (Get<string>(c,"link") ?? "");
                            idStr = "c_" + Md5Hex(baseKey).Substring(0, 8);
                        }
                        list.Add(new Dictionary<string,object>{
                            {"source","custom"}, {"id", idStr},
                            {"name", Get<string>(c,"name") ?? ""}, {"desc", Get<string>(c,"desc") ?? ""},
                            {"link", Get<string>(c,"link") ?? ""}, {"sort", sort},
                            {"category", cat}, {"submission_id", null}
                        });
                    }
                    foreach(var o in subs){
                        var s = o as Dictionary<string,object>; if(s == null) continue;
                        if(Get<string>(s,"category") != cat) continue;
                        if(Get<string>(s,"status") != "approved") continue;
                        int sort = ++maxSort;
                        list.Add(new Dictionary<string,object>{
                            {"source","submission"}, {"id","sub_"+Get<string>(s,"id")},
                            {"name", Get<string>(s,"site_name") ?? ""}, {"desc", Get<string>(s,"site_desc") ?? ""},
                            {"link", Get<string>(s,"site_url") ?? ""}, {"sort", sort},
                            {"category", cat}, {"hidden", IsTruthy(Get<object>(s,"hidden"))},
                            {"user_email", Get<string>(s,"user_email") ?? ""}, {"contact", Get<string>(s,"contact") ?? ""},
                            {"submit_time", Get<string>(s,"submit_time") ?? ""}, {"audit_time", Get<string>(s,"audit_time") ?? ""},
                            {"submission_id", Get<string>(s,"id") ?? ""}
                        });
                    }
                    list.Sort((a,b) => {
                        var x = a as Dictionary<string,object>; var y = b as Dictionary<string,object>;
                        return Convert.ToInt32(x["sort"]).CompareTo(Convert.ToInt32(y["sort"]));
                    });
                    return list;
                };

                if(!string.IsNullOrEmpty(category)){
                    if(!validCats.Contains(category)) return Err("分类不正确");
                    return Ok(new Dictionary<string,object>{{"category",category},{"list", build(category)}});
                }
                var all = new Dictionary<string,object>();
                foreach(var k in validCats) all[k] = build(k);
                return Ok(all);
            }
            case "admin_manage_link": {
                if(Get<string>(input,"admin_token") != ADMIN_TOKEN_MD5) return Err("无权限");
                string op = (Get<string>(input,"op") ?? "").Trim();
                string src = (Get<string>(input,"source") ?? "custom").Trim();
                string category = (Get<string>(input,"category") ?? "").Trim();
                var validCats = new HashSet<string>(new []{"pay","server","dist","nav","login","blog","card","tool"});
                if(!validCats.Contains(category)) return Err("分类不正确");
                var validOps = new HashSet<string>(new []{"create","update","delete","purge","unhide"});
                if(!validOps.Contains(op)) return Err("操作类型不正确");
                if(src != "custom" && src != "submission") return Err("来源标识不正确");

                // ===== site_data load/save helpers =====
                Action<Dictionary<string,object>> saveSiteData = newSd => WriteJson(SITE_DATA_FILE, newSd);
                var sdRaw = ReadJson(SITE_DATA_FILE);
                var sd = sdRaw as Dictionary<string,object>; if(sd == null) sd = new Dictionary<string,object>();
                Dictionary<string,object> catsDict = null;
                if(sd.ContainsKey("categories")) catsDict = sd["categories"] as Dictionary<string,object>;
                if(catsDict == null){ catsDict = new Dictionary<string,object>(); sd["categories"] = catsDict; }
                List<object> catListObj;
                if(catsDict.ContainsKey(category)) catListObj = ToArray(catsDict[category]);
                else catListObj = new List<object>();

                if(src == "custom") {
                    int id = 0; try{ id = Convert.ToInt32(Get<object>(input,"id")); } catch{}
                    string name = (Get<string>(input,"name") ?? "").Trim();
                    string desc = (Get<string>(input,"desc") ?? "").Trim();
                    string link = (Get<string>(input,"link") ?? "").Trim();
                    int sort = 0; try{ sort = Convert.ToInt32(Get<object>(input,"sort")); } catch{}
                    if((op=="create"||op=="update") && (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(link)))
                        return Err("名称和链接不能为空");

                    if(op == "create") {
                        int maxId = 0, maxSort = 0;
                        foreach(var co in catListObj){
                            var c = co as Dictionary<string,object>; if(c==null) continue;
                            try{ int ci = Convert.ToInt32(Get<object>(c,"id")); if(ci>maxId) maxId=ci; } catch{}
                            try{ int cs = Convert.ToInt32(Get<object>(c,"sort")); if(cs>maxSort) maxSort=cs; } catch{}
                        }
                        if(sort <= 0) sort = maxSort + 1;
                        catListObj.Add(new Dictionary<string,object>{
                            {"id", maxId + 1}, {"name", name}, {"desc", desc}, {"link", link}, {"sort", sort}
                        });
                        catsDict[category] = catListObj;
                        saveSiteData(sd);
                        return Ok(new Dictionary<string,object>{{"id", maxId + 1}}, "已新增链接");
                    }
                    if(op == "update") {
                        if(id <= 0) return Err("链接ID缺失");
                        bool found = false;
                        foreach(var co in catListObj){
                            var c = co as Dictionary<string,object>; if(c==null) continue;
                            try{ if(Convert.ToInt32(Get<object>(c,"id")) == id){
                                c["name"] = name; c["desc"] = desc; c["link"] = link;
                                if(sort > 0) c["sort"] = sort;
                                found = true; break;
                            }} catch{}
                        }
                        if(!found) return Err("未找到该自定义链接");
                        catsDict[category] = catListObj;
                        saveSiteData(sd);
                        return Ok(msg: "已更新");
                    }
                    if(op == "delete") {
                        if(id <= 0) return Err("链接ID缺失");
                        int before = catListObj.Count;
                        catListObj.RemoveAll(co => {
                            var c = co as Dictionary<string,object>; if(c == null) return false;
                            try{ return Convert.ToInt32(Get<object>(c,"id")) == id; } catch{ return false; }
                        });
                        if(catListObj.Count == before) return Err("未找到该自定义链接");
                        catsDict[category] = catListObj;
                        saveSiteData(sd);
                        return Ok(msg: "已删除");
                    }
                    return Err("自定义链接不支持此操作：" + op);
                }

                // submission
                string subId = Get<string>(input,"submission_id") ?? (Get<string>(input,"id") ?? "");
                subId = (subId ?? "").Trim();
                if(subId.StartsWith("sub_")) subId = subId.Substring(4);
                if(string.IsNullOrEmpty(subId)) return Err("收录ID缺失");
                var subs = ToArray(ReadJson(SUBMISS_FILE));
                int idx = -1;
                for(int i = 0; i < subs.Count; i++){
                    var s = subs[i] as Dictionary<string,object>;
                    if(s != null && Get<string>(s,"id") == subId){ idx = i; break; }
                }
                if(idx < 0) return Err("收录记录不存在");
                var sub = subs[idx] as Dictionary<string,object>;
                if(op == "update"){
                    string name = (Get<string>(input,"name") ?? "").Trim();
                    string desc = (Get<string>(input,"desc") ?? "").Trim();
                    string link = (Get<string>(input,"link") ?? "").Trim();
                    if(string.IsNullOrEmpty(name) || string.IsNullOrEmpty(link)) return Err("名称和链接不能为空");
                    sub["site_name"] = name; sub["site_desc"] = desc; sub["site_url"] = link;
                    string nc = (Get<string>(input,"category_new") ?? "").Trim();
                    if(validCats.Contains(nc)) sub["category"] = nc;
                    WriteJson(SUBMISS_FILE, subs);
                    return Ok(msg: "已更新收录信息");
                }
                if(op == "delete"){
                    sub["hidden"] = true;
                    sub["hidden_at"] = TimeStr();
                    WriteJson(SUBMISS_FILE, subs);
                    return Ok(msg: "已从前台移除（在分类管理中可随时恢复展示）");
                }
                if(op == "unhide"){
                    sub.Remove("hidden"); sub.Remove("hidden_at");
                    WriteJson(SUBMISS_FILE, subs);
                    return Ok(msg: "已恢复前台展示");
                }
                if(op == "purge"){
                    subs.RemoveAt(idx);
                    WriteJson(SUBMISS_FILE, subs);
                    return Ok(msg: "已永久删除该收录记录");
                }
                return Err("收录记录不支持此操作：" + op);
            }
            case "admin_sync_site_data": {
                if(Get<string>(input,"admin_token") != ADMIN_TOKEN_MD5) return Err("无权限");
                var payload = Get<object>(input,"data") as Dictionary<string,object>;
                if(payload == null) return Err("无有效数据");
                var allowed = new HashSet<string>(new []{"settings","banner_ads","grid_ads","categories"});
                var clean = new Dictionary<string,object>();
                foreach(var k in allowed) if(payload.ContainsKey(k)) clean[k] = payload[k];
                if(clean.Count == 0) return Err("无有效数据");
                var sd = ReadJson(SITE_DATA_FILE) as Dictionary<string,object> ?? new Dictionary<string,object>();
                foreach(var kv in clean) sd[kv.Key] = kv.Value;
                WriteJson(SITE_DATA_FILE, sd);
                return Ok(msg: "同步成功");
            }
            case "get_site_data": {
                var sd = ReadJson(SITE_DATA_FILE) as Dictionary<string,object> ?? new Dictionary<string,object>();
                return Ok(sd);
            }
            case "active_ads":
            case "get_icp_config":
            case "ad_slots":
                // 这些是非核心接口，返回空数组让前端 gracefully fallback 到内置数据
                return Ok(new List<object>());
            default:
                return Err("【本地模拟服务器】未知 action: " + action);
            }
        }

        // ================== 请求处理 ==================
        static async void HandleContext(HttpListenerContext ctx) {
            try {
                var req = ctx.Request; var resp = ctx.Response;
                var path = HttpUtility.UrlDecode(req.Url.AbsolutePath);
                var query = HttpUtility.ParseQueryString(req.Url.Query);

                if(string.Equals(path, "/api.php", StringComparison.OrdinalIgnoreCase)) {
                    var action = query["action"] ?? "";
                    object input = new Dictionary<string,object>();
                    if(req.HttpMethod == "POST") {
                        input = ReadBody(req);
                        var d = input as Dictionary<string,object>;
                        if(d == null) { input = d = new Dictionary<string,object>(); }
                        foreach(string k in query.Keys) {
                            if(!string.IsNullOrEmpty(k)) d[k] = query[k];
                        }
                    }
                    var result = HandleApi(action, input);
                    WriteJsonResp(resp, 200, result);
                    return;
                }

                // 静态文件
                if(path == "/") path = "/index.html";
                string fp;
                try { fp = Path.GetFullPath(Path.Combine(ROOT, path.TrimStart('/','\\'))); }
                catch { resp.StatusCode = 403; resp.Close(); return; }
                if(!fp.StartsWith(ROOT, StringComparison.OrdinalIgnoreCase)) { resp.StatusCode = 403; resp.Close(); return; }
                if(!File.Exists(fp)) {
                    // fallback: 请求 .html 等且不存在 => 404
                    resp.StatusCode = 404; resp.Close(); return;
                }
                var ext = Path.GetExtension(fp) ?? "";
                string mime; if(!MIME.TryGetValue(ext, out mime)) mime = "application/octet-stream";
                var fi = new FileInfo(fp);
                var etag = "\"" + fi.Length.ToString("x") + "-" + fi.LastWriteTimeUtc.Ticks.ToString("x") + "\"";
                var ifNm = req.Headers["If-None-Match"];
                if(ifNm == etag) { resp.StatusCode = 304; resp.Close(); return; }
                var bytes = File.ReadAllBytes(fp);
                resp.StatusCode = 200;
                resp.ContentType = mime;
                resp.ContentLength64 = bytes.LongLength;
                resp.AddHeader("ETag", etag);
                resp.AddHeader("Cache-Control", "no-cache");
                resp.AddHeader("Access-Control-Allow-Origin", "*");
                await resp.OutputStream.WriteAsync(bytes, 0, bytes.Length);
                resp.OutputStream.Close();
            } catch (Exception e) {
                Console.Error.WriteLine("[HandleContext Error] " + e.GetType().Name + ": " + e.Message);
                try { ctx.Response.StatusCode = 500; ctx.Response.Close(); } catch {}
            }
        }

        // ================== 入口 ==================
        public static void Run(int port) {
            var prefix = "http://localhost:" + port + "/";
            using(var listener = new HttpListener()) {
                listener.Prefixes.Add(prefix);
                try { listener.Start(); }
                catch(Exception e) {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("❌ 无法启动服务器（端口 "+port+" 被占用或需要管理员权限）: " + e.Message);
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("提示：换端口可用 -Port 5174，或以管理员身份运行 PowerShell 后重试。");
                    Console.ResetColor();
                    return;
                }
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine(@"
╔══════════════════════════════════════════════════════════╗
║   🎉 欢欢云导航 - 本地测试服务器 v2 启动成功(C# 异步内核) ║
╠══════════════════════════════════════════════════════════╣
║   首页:    http://localhost:" + port + @"/                       ║
║   后台:    http://localhost:" + port + @"/admin.html             ║
║   API:     http://localhost:" + port + @"/api.php?action=xxx     ║
║   数据目录: " + DATA_DIR + ((DATA_DIR.Length < 50) ? new string(' ', 50 - DATA_DIR.Length) : "") + @"║
╠══════════════════════════════════════════════════════════╣
║   ADMIN_TOKEN_MD5 = " + ADMIN_TOKEN_MD5 + @"                     ║
╚══════════════════════════════════════════════════════════╝
 停止服务器：Ctrl+C 或 关闭此窗口
");
                Console.ResetColor();
                while(listener.IsListening) {
                    try {
                        var ctx = listener.GetContext();
                        ThreadPool.QueueUserWorkItem(_ => HandleContext(ctx));
                    } catch (Exception e) {
                        if(!listener.IsListening) break;
                        Console.Error.WriteLine("[Accept Error] " + e.Message);
                        Thread.Sleep(50);
                    }
                }
            }
        }
    }
}
"@;

# 清理旧编译（防止 Add-Type 重复编译的缓存）
try {
    $tmpDll = Join-Path $env:TEMP 'HhNavLocalServer.dll'
    if (Test-Path $tmpDll) { Remove-Item $tmpDll -Force -ErrorAction SilentlyContinue }
} catch {}

Add-Type -TypeDefinition $src -ReferencedAssemblies @('System.Web', 'System.Web.Extensions') -ErrorAction Stop;
Write-Host "✅ C# 内核编译完成, 即将启动服务器..." -ForegroundColor Green;
[HhNavLocalServer.Program]::Run($Port);
