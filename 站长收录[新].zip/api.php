<?php
/**
 * 欢欢云导航 - 后端 API
 * 功能：邮件验证码发送、用户注册登录、网站收录提交与审核
 */

error_reporting(E_ERROR | E_PARSE);
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit(0); }

// ========== 配置 ==========
// SMTP 配置改为后台保存，见 data/email_config.json；$DEFAULT_EMAIL_FALLBACK 为首次迁移值

$DATA_DIR = __DIR__ . '/data';
if (!is_dir($DATA_DIR)) {
    if (!@mkdir($DATA_DIR, 0755, true) && !is_dir($DATA_DIR)) {
        json_exit(['ok' => false, 'msg' => '数据目录创建失败，请检查写入权限：' . $DATA_DIR]);
    }
}
// 预创建必要的 JSON 文件，避免第一次 readJson 返回空数组造成的逻辑混乱
foreach (['users.json', 'sessions.json', 'submissions.json', 'ad_slots.json', 'ad_orders.json'] as $f) {
    $p = $DATA_DIR . '/' . $f;
    if (!file_exists($p)) { @file_put_contents($p, '[]'); }
}
foreach (['site_data.json', 'alipay_config.json', 'email_config.json', 'icp_config.json'] as $f) {
    $p = $DATA_DIR . '/' . $f;
    if (!file_exists($p)) { @file_put_contents($p, '{}'); }
}

// ========== 数据目录/权限预检（写入失败的第一手诊断） ==========
if (!is_writable($DATA_DIR)) {
    // 尝试自动修复：chmod到0755（仅在所有者匹配时生效）
    @chmod($DATA_DIR, 0755);
    clearstatcache(true, $DATA_DIR);
}
if (!is_writable($DATA_DIR)) {
    $perms = @fileperms($DATA_DIR);
    $permsStr = $perms ? substr(sprintf('%o', $perms), -4) : 'n/a';
    $owner = function_exists('posix_getpwuid') && function_exists('fileowner')
        ? (($u = @posix_getpwuid(@fileowner($DATA_DIR))) ? $u['name'] : 'n/a')
        : 'n/a (Windows)';
    $space = @disk_free_space($DATA_DIR);
    $spaceStr = $space === false ? 'n/a' : round($space / 1048576, 1) . ' MB';
    $msg = '数据目录不可写入（宝塔/线上常见原因：www用户对data目录没有写权限）。'
         . ' 请在宝塔文件管理或SSH执行： chown -R www:www ' . escapeshellarg($DATA_DIR)
         . ' && chmod -R 755 ' . escapeshellarg($DATA_DIR)
         . '  (诊断：path=' . $DATA_DIR . ' perms=' . $permsStr . ' owner=' . $owner . ' free=' . $spaceStr . ')';
    json_exit(['ok' => false, 'msg' => $msg]);
}

// ========== 工具函数 ==========
function json_exit($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function readJson($file) {
    if (!file_exists($file)) return [];
    $content = @file_get_contents($file);
    if ($content === false || $content === '' || $content === null) return [];
    $data = json_decode($content, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        // 文件损坏：记录错误并返回空数组，防止整站崩溃
        @file_put_contents(dirname($file) . '/read_error.log', date('Y-m-d H:i:s') . '  JSON损坏：' . $file . ' -> ' . json_last_error_msg() . PHP_EOL, FILE_APPEND);
        return [];
    }
    return is_array($data) ? $data : [];
}

function writeJson($file, $data) {
    $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    if ($json === false) {
        $err = 'JSON编码失败：' . json_last_error_msg();
        @file_put_contents(dirname($file) . '/write_error.log', date('Y-m-d H:i:s') . '  ' . $err . '  file=' . $file . PHP_EOL, FILE_APPEND);
        // 同时写入全局错误日志，便于宝塔面板查看
        @error_log('[writeJson] ' . $err . ' file=' . $file);
        write_json_set_last_error($err);
        return false;
    }
    $dir = dirname($file);
    // 1. 自动创建父目录（兼容跨平台、多层级缺失）
    if (!is_dir($dir)) {
        if (!@mkdir($dir, 0755, true) && !is_dir($dir)) {
            $last = error_get_last();
            $err = '父目录创建失败：path=' . $dir . ' detail=' . ($last['message'] ?? 'unknown');
            @file_put_contents(($dir ?: __DIR__) . '/write_error.log', date('Y-m-d H:i:s') . '  ' . $err . PHP_EOL, FILE_APPEND);
            @error_log('[writeJson] ' . $err);
            write_json_set_last_error($err);
            return false;
        }
    }
    // 2. 目录是否可写的明确检测
    if (!is_writable($dir)) {
        $space = @disk_free_space($dir);
        $perms = @fileperms($dir);
        $err = '父目录不可写：dir=' . $dir
             . ' owner_writable=' . (is_writable($dir) ? 'yes' : 'no')
             . ' perms=' . ($perms ? substr(sprintf('%o', $perms), -4) : 'n/a')
             . ' free_MB=' . ($space === false ? 'n/a' : round($space / 1048576, 1));
        @file_put_contents($dir . '/write_error.log', date('Y-m-d H:i:s') . '  ' . $err . PHP_EOL, FILE_APPEND);
        @error_log('[writeJson] ' . $err);
        write_json_set_last_error($err);
        return false;
    }
    // 3. 目标文件存在时尝试清理只读属性（Windows/部分Linux文件系统场景）
    if (file_exists($file) && !is_writable($file)) {
        @chmod($file, 0644);
        clearstatcache(true, $file);
    }
    // 4. 写入同目录临时文件 + 原子rename/replace（保证不会半写损坏原文件）
    $tmp = $dir . '/.' . basename($file) . '.tmp.' . bin2hex(random_bytes(6)) . '.part';
    $fp = @fopen($tmp, 'xb'); // 'x' = CreateNew 独占创建，保证并发下tmp名不冲突
    if (!$fp) {
        $last = error_get_last();
        $err = '临时文件创建失败（目录写入权限/磁盘已满/安全软件拦截？）：tmp=' . $tmp . ' detail=' . ($last['message'] ?? 'unknown');
        @file_put_contents($dir . '/write_error.log', date('Y-m-d H:i:s') . '  ' . $err . PHP_EOL, FILE_APPEND);
        @error_log('[writeJson] ' . $err);
        write_json_set_last_error($err);
        return false;
    }
    $written = 0; $len = strlen($json);
    // 分段写入（避免超大JSON一次写入被截断）
    while ($written < $len) {
        $n = @fwrite($fp, substr($json, $written));
        if ($n === false || $n === 0) { break; }
        $written += $n;
    }
    $flushOk = @fflush($fp);
    $closeOk = @fclose($fp);

    if ($written !== $len || !$flushOk || !$closeOk) {
        $space = @disk_free_space($dir);
        $err = '临时文件写入不完整：tmp=' . $tmp
             . ' expected=' . $len . ' written=' . $written
             . ' flush=' . ($flushOk ? 'ok' : 'fail') . ' close=' . ($closeOk ? 'ok' : 'fail')
             . ' free_MB=' . ($space === false ? 'n/a' : round($space / 1048576, 1));
        @file_put_contents($dir . '/write_error.log', date('Y-m-d H:i:s') . '  ' . $err . PHP_EOL, FILE_APPEND);
        @error_log('[writeJson] ' . $err);
        @unlink($tmp);
        write_json_set_last_error($err);
        return false;
    }
    // 5. 原子替换：rename 在同分区下是原子操作
    if (file_exists($file)) {
        // PHP >= 7.0 下 rename 目标存在会覆盖（Linux/Windows 均支持）
        // 若 rename 失败，尝试 unlink + rename 两步（极少数环境会失败）
        if (!@rename($tmp, $file)) {
            if (@unlink($file) && @rename($tmp, $file)) {
                // OK
            } else {
                $last = error_get_last();
                $err = '原子替换失败：file=' . $file . ' tmp=' . $tmp . ' detail=' . ($last['message'] ?? 'unknown');
                @file_put_contents($dir . '/write_error.log', date('Y-m-d H:i:s') . '  ' . $err . PHP_EOL, FILE_APPEND);
                @error_log('[writeJson] ' . $err);
                @unlink($tmp);
                write_json_set_last_error($err);
                return false;
            }
        }
    } else {
        if (!@rename($tmp, $file)) {
            $last = error_get_last();
            $err = '首次移动到目标文件失败：file=' . $file . ' tmp=' . $tmp . ' detail=' . ($last['message'] ?? 'unknown');
            @file_put_contents($dir . '/write_error.log', date('Y-m-d H:i:s') . '  ' . $err . PHP_EOL, FILE_APPEND);
            @error_log('[writeJson] ' . $err);
            @unlink($tmp);
            write_json_set_last_error($err);
            return false;
        }
    }
    // 6. 设置合理权限（Linux宝塔环境：644 = owner rw, others r）
    @chmod($file, 0644);
    clearstatcache(true, $file);
    return true;
}

// 保存最近一次 writeJson 的详细错误，供上层返回给前端（比单纯"权限异常"更有诊断力）
function write_json_set_last_error($msg) {
    global $WRITE_JSON_LAST_ERR;
    $GLOBALS['WRITE_JSON_LAST_ERR'] = $msg;
}
function write_json_last_error() {
    return isset($GLOBALS['WRITE_JSON_LAST_ERR']) ? $GLOBALS['WRITE_JSON_LAST_ERR'] : '';
}

function getInput() {
    $raw = @file_get_contents('php://input');
    $raw = is_string($raw) ? trim($raw) : '';
    if ($raw === '') { return $_POST ?: []; }
    $data = json_decode($raw, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        // 让调用端知道请求体非法（通常是前端格式错、或 body 意外截断）
        return ['_parse_error' => true, '_parse_msg' => json_last_error_msg(), '_raw_len' => strlen($raw)];
    }
    if (!is_array($data)) { $data = $_POST ?: []; }
    return $data;
}

function genId() {
    return date('YmdHis') . sprintf('%03d', rand(0, 999));
}

// ========== SMTP 邮件发送类 ==========
class SmtpMail {
    private $host;
    private $port;
    private $user;
    private $pass;
    private $socket;

    public function __construct($host, $port, $user, $pass) {
        $this->host = $host;
        $this->port = $port;
        $this->user = $user;
        $this->pass = $pass;
    }

    public function send($to, $subject, $htmlBody) {
        $remote = 'ssl://' . $this->host . ':' . $this->port;
        $this->socket = @stream_socket_client($remote, $errno, $errstr, 30);
        if (!$this->socket) {
            throw new Exception("SMTP连接失败: $errstr ($errno)，请检查PHP openssl扩展是否启用");
        }

        $this->readResponse(); // 220
        $this->sendCmd("EHLO huanhuanyun\r\n", '250');
        $this->sendCmd("AUTH LOGIN\r\n", '334');
        $this->sendCmd(base64_encode($this->user) . "\r\n", '334');
        $this->sendCmd(base64_encode($this->pass) . "\r\n", '235');
        $this->sendCmd("MAIL FROM:<{$this->user}>\r\n", '250');
        $this->sendCmd("RCPT TO:<{$to}>\r\n", '250');
        $this->sendCmd("DATA\r\n", '354');

        $boundary = md5(uniqid());
        $encodedSubject = '=?UTF-8?B?' . base64_encode($subject) . '?=';
        $headers = [
            "From: {$this->user}",
            "To: {$to}",
            "Subject: {$encodedSubject}",
            "MIME-Version: 1.0",
            "Content-Type: text/html; charset=UTF-8",
            "Content-Transfer-Encoding: base64"
        ];

        // 按 RFC 2045 规范：base64 编码每行不得超过 76 字符，防止 SMTP 500 Line too long (RFC 5321 998 字节限制)
        $encodedBody = chunk_split(base64_encode($htmlBody), 76, "\r\n");
        $msg = implode("\r\n", $headers) . "\r\n\r\n" . $encodedBody . ".\r\n";
        $this->sendCmd($msg, '250');
        $this->sendCmd("QUIT\r\n", '221');
        fclose($this->socket);
        return true;
    }

    private function sendCmd($cmd, $expectedCode) {
        fwrite($this->socket, $cmd);
        $resp = $this->readResponse();
        $code = substr($resp, 0, 3);
        if ($code != $expectedCode) {
            throw new Exception("SMTP错误: {$resp}（期望 {$expectedCode}）");
        }
        return $resp;
    }

    private function readResponse() {
        $resp = '';
        while (($line = fgets($this->socket, 515)) !== false) {
            $resp .= $line;
            if (isset($line[3]) && $line[3] === ' ') break;
        }
        return $resp;
    }
}

// 读取SMTP配置：优先从 data/email_config.json，缺失则迁移旧默认值
function getEmailConfig() {
    global $EMAIL_CONFIG_FILE, $DEFAULT_EMAIL_FALLBACK;
    $cfg = readJson($EMAIL_CONFIG_FILE);
    if (empty($cfg['smtp_host']) || empty($cfg['smtp_user']) || empty($cfg['smtp_pass'])) {
        // 首次使用：写入旧默认值
        $init = array_merge($DEFAULT_EMAIL_FALLBACK, [
            'migrated_from' => 'hardcoded_default',
            'migrated_at'   => date('Y-m-d H:i:s')
        ]);
        writeJson($EMAIL_CONFIG_FILE, $init);
        return $init;
    }
    return $cfg;
}

function sendMail($to, $subject, $htmlBody) {
    $cfg = getEmailConfig();
    $mailer = new SmtpMail($cfg['smtp_host'], intval($cfg['smtp_port']), $cfg['smtp_user'], $cfg['smtp_pass']);
    // 发送时把发件人姓名合并到主题前缀（部分SMTP客户端显示效果更好）
    $prefix = !empty($cfg['site_name']) ? ('[' . $cfg['site_name'] . '] ') : '';
    $mailer->send($to, $prefix . $subject, $htmlBody);
}

// 获取前台站点名称（优先email_config里的site_name，兼容旧常量）
function getSiteName() {
    $cfg = getEmailConfig();
    return !empty($cfg['site_name']) ? $cfg['site_name'] : '欢欢云导航';
}

// ========== 数据文件 ==========
$USERS_FILE = $DATA_DIR . '/users.json';
$CODES_FILE = $DATA_DIR . '/codes.json';
$SUBMISSIONS_FILE = $DATA_DIR . '/submissions.json';
$SESSIONS_FILE = $DATA_DIR . '/sessions.json';
$AD_SLOTS_FILE = $DATA_DIR . '/ad_slots.json';
$AD_ORDERS_FILE = $DATA_DIR . '/ad_orders.json';
$SITE_DATA_FILE = $DATA_DIR . '/site_data.json';       // 轮播广告、图文广告、分类链接（PC/手机端共享）
$ALIPAY_CONFIG_FILE = $DATA_DIR . '/alipay_config.json'; // 支付宝当面付密钥配置（后台保存）
$ZFB_TXT_FILE = __DIR__ . '/zfb.txt';                   // 旧的密钥文件，仅首次迁移用
$EMAIL_CONFIG_FILE = $DATA_DIR . '/email_config.json'; // 邮箱SMTP配置（后台保存）
$ICP_CONFIG_FILE   = $DATA_DIR . '/icp_config.json';   // 备案号配置（后台保存）
// 旧默认SMTP（首次迁移用，不再作为实际发送配置）
$DEFAULT_EMAIL_FALLBACK = [
    'smtp_host' => 'smtp.126.com',
    'smtp_port' => 465,
    'smtp_secure' => 'ssl',
    'smtp_user' => 'huanhuanyun@126.com',
    'smtp_pass' => 'CNx7WKQXRbc7ZktW',
    'sender_name' => '欢欢云导航',
    'site_name'   => '欢欢云导航'
];

// ========== 用户会话校验 ==========
function checkUserSession($token) {
    global $SESSIONS_FILE;
    if (empty($token)) return null;
    $sessions = readJson($SESSIONS_FILE);
    if (!isset($sessions[$token])) return null;
    if (time() > $sessions[$token]['expire']) return null;
    return $sessions[$token];
}

// ========== 广告位默认配置 ==========
class AdHelper {
    public static function defaultSlots() {
        return [
            'banner_top' => [
                'name' => '首页顶部轮播广告位',
                'desc' => '首页顶部 1200×450 大图轮播位（高曝光）',
                'size' => '1200×450',
                'enabled' => true,
                'plans' => [
                    'month'   => ['name' => '月卡', 'price' => 199, 'days' => 30],
                    'quarter' => ['name' => '季卡', 'price' => 539, 'days' => 90],
                    'year'    => ['name' => '年卡', 'price' => 1999, 'days' => 365]
                ]
            ],
            'grid_home' => [
                'name' => '热门服务推荐图文位',
                'desc' => '首页8格图文推荐位（单个位置）',
                'size' => '300×200',
                'enabled' => true,
                'plans' => [
                    'month'   => ['name' => '月卡', 'price' => 89,  'days' => 30],
                    'quarter' => ['name' => '季卡', 'price' => 239, 'days' => 90],
                    'year'    => ['name' => '年卡', 'price' => 799, 'days' => 365]
                ]
            ],
            'sidebar_top' => [
                'name' => '侧边栏顶部广告位',
                'desc' => '侧边栏顶部图文广告位（中等曝光）',
                'size' => '300×250',
                'enabled' => false,
                'plans' => [
                    'month'   => ['name' => '月卡', 'price' => 69,  'days' => 30],
                    'quarter' => ['name' => '季卡', 'price' => 179, 'days' => 90],
                    'year'    => ['name' => '年卡', 'price' => 599, 'days' => 365]
                ]
            ]
        ];
    }
}

// ========== 支付宝当面付 ==========
// 密钥来源：优先 data/alipay_config.json（后台保存），缺失则从 zfb.txt 迁移
class AlipayFacePay {
    private static $appId;
    private static $appPrivateKey;
    private static $alipayPublicKey;
    private static $gateway = 'https://openapi.alipay.com/gateway.do';
    private static $inited = false;

    public static function init() {
        if (self::$inited) return;
        self::$inited = true;
        global $ALIPAY_CONFIG_FILE, $ZFB_TXT_FILE;

        $cfg = readJson($ALIPAY_CONFIG_FILE);
        // 如果配置文件为空，尝试从 zfb.txt 迁移
        if (empty($cfg['app_id']) || empty($cfg['app_private_key']) || empty($cfg['alipay_public_key'])) {
            $migrated = self::migrateFromZfbTxt($ZFB_TXT_FILE);
            if ($migrated) {
                writeJson($ALIPAY_CONFIG_FILE, $migrated);
                $cfg = $migrated;
            }
        }
        self::$appId          = $cfg['app_id']          ?? '';
        self::$appPrivateKey  = $cfg['app_private_key'] ?? '';
        self::$alipayPublicKey= $cfg['alipay_public_key'] ?? '';
    }

    // 解析 zfb.txt 格式：第2行为应用ID，第4行为私钥，第6行为支付宝公钥
    private static function migrateFromZfbTxt($zfbFile) {
        if (!file_exists($zfbFile)) return null;
        $lines = @file($zfbFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (!$lines || count($lines) < 6) return null;
        $id = trim($lines[1] ?? '');
        $pk = trim($lines[3] ?? '');
        $pub = trim($lines[5] ?? '');
        if (empty($id) || empty($pk) || empty($pub)) return null;
        return [
            'app_id'           => $id,
            'app_private_key'  => $pk,
            'alipay_public_key'=> $pub,
            'migrated_from'    => 'zfb.txt',
            'migrated_at'      => date('Y-m-d H:i:s')
        ];
    }

    // 后台保存新配置后，重置内部静态缓存，让后续调用使用新值
    public static function resetStatic() {
        self::$appId = null;
        self::$appPrivateKey = null;
        self::$alipayPublicKey = null;
        self::$inited = false;
    }

    // 调试日志（写入 data/alipay_debug.log）
    private static function log($tag, $content) {
        global $DATA_DIR;
        $logFile = $DATA_DIR . '/alipay_debug.log';
        $line = '[' . date('Y-m-d H:i:s') . '] [' . $tag . '] ' . $content . "\n";
        @file_put_contents($logFile, $line, FILE_APPEND);
    }

    // 预下单：返回二维码链接
    public static function precreate($outTradeNo, $totalAmount, $subject) {
        self::init();
        if (empty(self::$appId) || empty(self::$appPrivateKey)) {
            return ['ok' => false, 'msg' => '支付宝密钥未配置，请联系管理员到后台填写'];
        }
        $bizContent = [
            'out_trade_no'  => $outTradeNo,
            'total_amount'  => number_format(floatval($totalAmount), 2, '.', ''),
            'subject'       => $subject,
            'timeout_express' => '30m'
        ];
        $params = self::buildBaseParams('alipay.trade.precreate', $bizContent);
        $resp = self::postRequest($params);
        // 记录原始响应便于排查
        self::log('PRECREATE_RAW', 'order=' . $outTradeNo . ' resp=' . substr($resp, 0, 2000));
        $data = self::parseResponse($resp, 'alipay_trade_precreate_response');
        if (!$data) {
            // 解析失败，附带详细原因
            $reason = self::diagnoseFailure($resp);
            self::log('PRECREATE_FAIL', $reason);
            return ['ok' => false, 'msg' => '支付宝响应解析失败：' . $reason];
        }
        if (($data['code'] ?? '') !== '10000') {
            $msg = $data['sub_msg'] ?? $data['msg'] ?? '下单失败';
            $code = $data['sub_code'] ?? $data['code'] ?? '';
            self::log('PRECREATE_ERROR', 'code=' . $code . ' msg=' . $msg);
            return ['ok' => false, 'msg' => $msg . ($code ? '（' . $code . '）' : '')];
        }
        $qrCode = $data['qr_code'] ?? '';
        if (empty($qrCode)) {
            self::log('PRECREATE_ERROR', 'qr_code为空');
            return ['ok' => false, 'msg' => '支付宝未返回二维码'];
        }
        self::log('PRECREATE_OK', 'order=' . $outTradeNo);
        return ['ok' => true, 'qr_code' => $qrCode];
    }

    // 订单查询
    public static function query($outTradeNo) {
        self::init();
        if (empty(self::$appId) || empty(self::$appPrivateKey)) {
            return ['ok' => false];
        }
        $bizContent = ['out_trade_no' => $outTradeNo];
        $params = self::buildBaseParams('alipay.trade.query', $bizContent);
        $resp = self::postRequest($params);
        self::log('QUERY_RAW', 'order=' . $outTradeNo . ' resp=' . substr($resp, 0, 2000));
        $data = self::parseResponse($resp, 'alipay_trade_query_response');
        if (!$data) {
            self::log('QUERY_FAIL', self::diagnoseFailure($resp));
            return ['ok' => false];
        }
        if (($data['code'] ?? '') === '10000' && ($data['trade_status'] ?? '') === 'TRADE_SUCCESS') {
            self::log('QUERY_OK', 'order=' . $outTradeNo . ' paid');
            return ['ok' => true, 'trade_status' => 'TRADE_SUCCESS', 'trade_no' => $data['trade_no'] ?? ''];
        }
        return ['ok' => false, 'trade_status' => $data['trade_status'] ?? ''];
    }

    private static function buildBaseParams($method, $bizContent) {
        return [
            'app_id'      => self::$appId,
            'method'      => $method,
            'format'      => 'JSON',
            'charset'     => 'utf-8',
            'sign_type'   => 'RSA2',
            'timestamp'   => date('Y-m-d H:i:s'),
            'version'     => '1.0',
            'biz_content' => json_encode($bizContent, JSON_UNESCAPED_UNICODE)
        ];
    }

    // RSA2 签名
    private static function generateSign($params) {
        ksort($params);
        $pairs = [];
        foreach ($params as $k => $v) {
            if ($k === 'sign' || $v === '' || $v === null) continue;
            $pairs[] = $k . '=' . $v;
        }
        $signStr = implode('&', $pairs);
        // 应用私钥来自 zfb.txt，为 PKCS#8 格式，使用 BEGIN PRIVATE KEY 头
        $pk = "-----BEGIN PRIVATE KEY-----\n" .
              wordwrap(self::$appPrivateKey, 64, "\n", true) .
              "\n-----END PRIVATE KEY-----";
        $ok = openssl_sign($signStr, $signature, $pk, OPENSSL_ALGO_SHA256);
        if (!$ok || empty($signature)) {
            $err = openssl_error_string();
            self::log('SIGN_FAIL', 'openssl_sign失败: ' . $err . ' | signStr=' . substr($signStr, 0, 500));
            return '';
        }
        return base64_encode($signature);
    }

    // POST 请求（支付宝网关只接受 POST）
    private static function postRequest($params) {
        $sign = self::generateSign($params);
        if (empty($sign)) {
            self::log('POST_ABORT', '签名生成失败，请求中止');
            return '';
        }
        $params['sign'] = $sign;
        $postData = http_build_query($params, '', '&');

        // 优先使用 curl
        if (function_exists('curl_init')) {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, self::$gateway);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 30);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/x-www-form-urlencoded;charset=UTF-8']);
            $resp = curl_exec($ch);
            if ($resp === false) {
                $err = curl_error($ch);
                $errno = curl_errno($ch);
                self::log('CURL_ERROR', 'errno=' . $errno . ' err=' . $err);
                curl_close($ch);
                return '';
            }
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            self::log('CURL_OK', 'http_code=' . $httpCode);
            return $resp;
        }

        // file_get_contents 回退
        self::log('POST_FALLBACK', 'curl不可用，使用file_get_contents');
        $ctx = stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/x-www-form-urlencoded;charset=UTF-8\r\n",
                'content' => $postData,
                'timeout' => 30
            ],
            'ssl' => ['verify_peer' => false, 'verify_peer_name' => false]
        ]);
        $resp = @file_get_contents(self::$gateway, false, $ctx);
        if ($resp === false) {
            $lastErr = error_get_last();
            $errMsg = is_array($lastErr) ? ($lastErr['message'] ?? 'unknown') : 'unknown';
            self::log('FGC_ERROR', 'file_get_contents失败: ' . $errMsg);
            return '';
        }
        return $resp;
    }

    private static function parseResponse($resp, $responseKey) {
        if (empty($resp)) return null;
        $arr = json_decode($resp, true);
        if (!is_array($arr)) return null;
        if (!isset($arr[$responseKey])) return null;
        return $arr[$responseKey];
    }

    // 诊断解析失败的具体原因
    private static function diagnoseFailure($resp) {
        if (empty($resp)) return '响应为空（curl请求失败或网络不通）';
        $arr = json_decode($resp, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            return 'JSON解析失败[' . json_last_error_msg() . ']，响应前200字符：' . substr($resp, 0, 200);
        }
        if (!is_array($arr)) return '响应非JSON对象';
        // 检查是否是签名错误（支付宝会返回 sign_verify_fail）
        if (isset($arr['error_response'])) {
            $err = $arr['error_response'];
            return '支付宝error_response: code=' . ($err['code'] ?? '') . ' msg=' . ($err['msg'] ?? '') . ' sub_code=' . ($err['sub_code'] ?? '') . ' sub_msg=' . ($err['sub_msg'] ?? '');
        }
        $keys = implode(',', array_keys($arr));
        return '响应中缺少期望字段，实际包含：' . $keys;
    }
}

// ========== API 路由 ==========
$action = $_GET['action'] ?? (getInput()['action'] ?? '');
$input = getInput();

switch ($action) {

    // ========== 1. 发送验证码 ==========
    case 'send_code':
        $email = trim($input['email'] ?? '');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            json_exit(['ok' => false, 'msg' => '邮箱格式不正确']);
        }

        // 检查是否已注册（注册场景需未注册 / 找回密码场景需已注册）
        $mode = $input['mode'] ?? 'register';
        $users = readJson($USERS_FILE);
        if ($mode === 'register') {
            foreach ($users as $u) {
                if ($u['email'] === $email) {
                    json_exit(['ok' => false, 'msg' => '该邮箱已注册，请直接登录']);
                }
            }
        } else if ($mode === 'forgot') {
            $found = false;
            foreach ($users as $u) {
                if ($u['email'] === $email) { $found = true; break; }
            }
            if (!$found) {
                json_exit(['ok' => false, 'msg' => '该邮箱未注册，请先注册']);
            }
        }

        // 频率限制：60秒内只能发一次
        $codes = readJson($CODES_FILE);
        if (isset($codes[$email]) && (time() - $codes[$email]['time']) < 60) {
            json_exit(['ok' => false, 'msg' => '验证码已发送，请60秒后再试']);
        }

        // 生成6位验证码
        $code = sprintf('%06d', rand(100000, 999999));
        $codes[$email] = [
            'code' => $code,
            'mode' => $mode, // register / forgot
            'time' => time(),
            'expire' => time() + 600 // 10分钟有效
        ];
        writeJson($CODES_FILE, $codes);

        // 发送邮件（主题前缀 sendMail 里会加，这里直接写核心标题）
        $siteName = getSiteName();
        $subject = '邮箱验证码';
        $html = "<div style='max-width:480px;margin:0 auto;font-family:Microsoft YaHei,sans-serif;'>
            <div style='background:linear-gradient(135deg,#2563eb,#38bdf8);padding:30px;border-radius:12px 12px 0 0;text-align:center;'>
                <h1 style='color:#fff;margin:0;font-size:24px;'>{$siteName}</h1>
                <p style='color:rgba(255,255,255,0.8);margin:5px 0 0;'>邮箱验证码</p>
            </div>
            <div style='background:#fff;padding:30px;border:1px solid #e2e8f0;border-top:none;border-radius:0 0 12px 12px;'>
                <p>您好，您正在进行邮箱验证，验证码为：</p>
                <div style='text-align:center;margin:20px 0;'>
                    <span style='font-size:32px;font-weight:bold;color:#2563eb;letter-spacing:6px;background:#f0f7ff;padding:15px 30px;border-radius:8px;display:inline-block;'>{$code}</span>
                </div>
                <p style='color:#666;font-size:14px;'>验证码10分钟内有效，请尽快使用。</p>
                <p style='color:#999;font-size:12px;margin-top:20px;border-top:1px solid #f0f0f0;padding-top:15px;'>如非本人操作，请忽略此邮件。</p>
            </div>
        </div>";

        try {
            sendMail($email, $subject, $html);
            json_exit(['ok' => true, 'msg' => '验证码已发送至您的邮箱，请查收']);
        } catch (Exception $e) {
            json_exit(['ok' => false, 'msg' => '邮件发送失败：' . $e->getMessage()]);
        }
        break;

    // ========== 2. 用户注册 ==========
    case 'register':
        $email = trim($input['email'] ?? '');
        $password = $input['password'] ?? '';
        $code = trim($input['code'] ?? '');

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            json_exit(['ok' => false, 'msg' => '邮箱格式不正确']);
        }
        if (strlen($password) < 6) {
            json_exit(['ok' => false, 'msg' => '密码至少6位']);
        }
        if (strlen($code) !== 6) {
            json_exit(['ok' => false, 'msg' => '请输入6位验证码']);
        }

        // 验证验证码
        $codes = readJson($CODES_FILE);
        if (!isset($codes[$email]) || $codes[$email]['code'] !== $code) {
            json_exit(['ok' => false, 'msg' => '验证码不正确']);
        }
        if (time() > $codes[$email]['expire']) {
            json_exit(['ok' => false, 'msg' => '验证码已过期，请重新获取']);
        }

        // 检查是否已注册
        $users = readJson($USERS_FILE);
        foreach ($users as $u) {
            if ($u['email'] === $email) {
                json_exit(['ok' => false, 'msg' => '该邮箱已注册']);
            }
        }

        // 创建用户
        $newUser = [
            'id' => genId(),
            'email' => $email,
            'password' => md5($password . 'hh_salt_2026'),
            'register_time' => date('Y-m-d H:i:s'),
            'status' => 'active'
        ];
        $users[] = $newUser;
        writeJson($USERS_FILE, $users);

        // 删除已用验证码
        unset($codes[$email]);
        writeJson($CODES_FILE, $codes);

        json_exit(['ok' => true, 'msg' => '注册成功，请登录']);
        break;

    // ========== 2.5 忘记密码 - 重置密码 ==========
    case 'reset_password':
        $email = trim($input['email'] ?? '');
        $password = $input['password'] ?? '';
        $code = trim($input['code'] ?? '');

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            json_exit(['ok' => false, 'msg' => '邮箱格式不正确']);
        }
        if (strlen($password) < 6) {
            json_exit(['ok' => false, 'msg' => '密码至少6位']);
        }
        if (strlen($code) !== 6) {
            json_exit(['ok' => false, 'msg' => '请输入6位验证码']);
        }

        // 校验验证码（必须是找回密码场景的验证码）
        $codes = readJson($CODES_FILE);
        if (!isset($codes[$email]) || $codes[$email]['code'] !== $code) {
            json_exit(['ok' => false, 'msg' => '验证码不正确']);
        }
        if (time() > $codes[$email]['expire']) {
            json_exit(['ok' => false, 'msg' => '验证码已过期，请重新获取']);
        }
        if (($codes[$email]['mode'] ?? 'register') !== 'forgot') {
            json_exit(['ok' => false, 'msg' => '验证码用途不正确，请重新获取']);
        }

        // 校验用户存在
        $users = readJson($USERS_FILE);
        $found = false;
        foreach ($users as &$u) {
            if ($u['email'] === $email) {
                $u['password'] = md5($password . 'hh_salt_2026');
                $found = true;
                break;
            }
        }
        unset($u);
        if (!$found) {
            json_exit(['ok' => false, 'msg' => '该邮箱未注册']);
        }
        writeJson($USERS_FILE, $users);

        // 删除已用验证码
        unset($codes[$email]);
        writeJson($CODES_FILE, $codes);

        json_exit(['ok' => true, 'msg' => '密码重置成功，请使用新密码登录']);
        break;

    // ========== 3. 用户登录 ==========
    case 'login':
        $email = trim($input['email'] ?? '');
        $password = $input['password'] ?? '';

        $users = readJson($USERS_FILE);
        foreach ($users as $u) {
            if ($u['email'] === $email && $u['password'] === md5($password . 'hh_salt_2026')) {
                if ($u['status'] !== 'active') {
                    json_exit(['ok' => false, 'msg' => '账号已被禁用，请联系管理员']);
                }
                // 生成 token
                $token = md5($email . time() . rand());
                $sessions = readJson($SESSIONS_FILE);
                $sessions[$token] = [
                    'email' => $email,
                    'user_id' => $u['id'],
                    'login_time' => time(),
                    'expire' => time() + 86400 * 7 // 7天有效
                ];
                if (!writeJson($SESSIONS_FILE, $sessions)) {
                    $_detail = write_json_last_error();
                    json_exit(['ok' => false, 'msg' => '登录状态保存失败：' . ($_detail ?: '请检查data目录写入权限，或查看data/write_error.log了解详情')]);
                }
                json_exit(['ok' => true, 'msg' => '登录成功', 'data' => ['token' => $token, 'email' => $email]]);
            }
        }
        json_exit(['ok' => false, 'msg' => '邮箱或密码错误']);
        break;

    // ========== 4. 验证登录状态 ==========
    case 'check_login':
        $token = $input['token'] ?? '';
        $sessions = readJson($SESSIONS_FILE);
        if (isset($sessions[$token]) && time() < $sessions[$token]['expire']) {
            json_exit(['ok' => true, 'data' => ['email' => $sessions[$token]['email']]]);
        }
        json_exit(['ok' => false, 'msg' => '未登录或登录已过期']);
        break;

    // ========== 5. 退出登录 ==========
    case 'logout':
        $token = $input['token'] ?? '';
        $sessions = readJson($SESSIONS_FILE);
        unset($sessions[$token]);
        writeJson($SESSIONS_FILE, $sessions);
        json_exit(['ok' => true, 'msg' => '已退出登录']);
        break;

    // ========== 6. 提交网站收录 ==========
    case 'submit_site':
        $token = $input['token'] ?? '';
        $sessions = readJson($SESSIONS_FILE);
        if (!isset($sessions[$token]) || time() > $sessions[$token]['expire']) {
            json_exit(['ok' => false, 'msg' => '请先登录后再提交']);
        }
        $userEmail = $sessions[$token]['email'];

        $siteName = trim($input['site_name'] ?? '');
        $siteUrl = trim($input['site_url'] ?? '');
        $siteDesc = trim($input['site_desc'] ?? '');
        $category = trim($input['category'] ?? '');
        $contact = trim($input['contact'] ?? '');

        if (empty($siteName) || empty($siteUrl) || empty($siteDesc) || empty($category)) {
            json_exit(['ok' => false, 'msg' => '请填写完整信息']);
        }

        $validCats = ['pay', 'server', 'dist', 'nav', 'login', 'blog', 'card', 'tool'];
        if (!in_array($category, $validCats)) {
            json_exit(['ok' => false, 'msg' => '分类不正确']);
        }

        $submissions = readJson($SUBMISSIONS_FILE);
        $newSub = [
            'id' => genId(),
            'user_email' => $userEmail,
            'site_name' => $siteName,
            'site_url' => $siteUrl,
            'site_desc' => $siteDesc,
            'category' => $category,
            'contact' => $contact,
            'status' => 'pending', // pending / approved / rejected
            'submit_time' => date('Y-m-d H:i:s'),
            'audit_time' => '',
            'audit_remark' => ''
        ];
        $submissions[] = $newSub;
        if (!writeJson($SUBMISSIONS_FILE, $submissions)) {
            $_detail = write_json_last_error();
            json_exit(['ok' => false, 'msg' => '收录提交保存失败：' . ($_detail ?: '请稍后重试或联系管理员，可查看data/write_error.log了解详情')]);
        }

        json_exit(['ok' => true, 'msg' => '提交成功！您的网站正在等待审核，审核通过后将在首页展示', 'data' => ['id' => $newSub['id']]]);
        break;

    // ========== 7. 获取已审核通过的收录（前台用）——过滤管理员在分类链接管理里隐藏掉的记录 ==========
    case 'approved_sites':
        $submissions = readJson($SUBMISSIONS_FILE);
        $approved = array_filter($submissions, function($s) {
            return ($s['status'] ?? '') === 'approved' && empty($s['hidden']);
        });
        $result = array_map(function($s) {
            return [
                'name' => $s['site_name'],
                'desc' => $s['site_desc'],
                'link' => $s['site_url'],
                'category' => $s['category']
            ];
        }, array_values($approved));
        json_exit(['ok' => true, 'data' => $result]);
        break;

    // ========== 7.1 后台获取指定分类的全部链接（自定义 + 已审核通过的用户收录）==========
    //   - 返回每条链接带 source: 'custom' | 'submission'
    //   - source=submission 带 submission_id，方便编辑/隐藏
    //   - 支持 category 为空时返回所有分类 {pay:[...], nav:[...], ...}
    case 'get_category_links': {
        $category = trim($input['category'] ?? '');
        $validCats = ['pay','server','dist','nav','login','blog','card','tool'];
        $siteData = readJson($SITE_DATA_FILE);
        $cats = isset($siteData['categories']) && is_array($siteData['categories']) ? $siteData['categories'] : [];
        $submissions = readJson($SUBMISSIONS_FILE);

        $buildOneCategory = function($catKey) use ($cats, $submissions) {
            $custom = isset($cats[$catKey]) && is_array($cats[$catKey]) ? $cats[$catKey] : [];
            $out = [];
            $maxSort = 0;
            foreach ($custom as $c) {
                if (!is_array($c)) continue;
                $sort = isset($c['sort']) ? (int)$c['sort'] : 0;
                if ($sort > $maxSort) $maxSort = $sort;
                $out[] = [
                    'source' => 'custom',
                    'id' => isset($c['id']) ? (string)$c['id'] : ('c_' . substr(md5(($c['name'] ?? '') . ($c['link'] ?? '')), 0, 8)),
                    'name' => $c['name'] ?? '',
                    'desc' => $c['desc'] ?? '',
                    'link' => $c['link'] ?? '',
                    'sort' => $sort,
                    'category' => $catKey,
                    'submission_id' => null
                ];
            }
            foreach ($submissions as $s) {
                if (!is_array($s)) continue;
                if (($s['category'] ?? '') !== $catKey) continue;
                if (($s['status'] ?? '') !== 'approved') continue;
                // 管理员隐藏掉的收录，在分类管理里仍然显示（可以取消隐藏），但前台不再展示
                $sort = ++$maxSort;
                $out[] = [
                    'source' => 'submission',
                    'id' => 'sub_' . ($s['id'] ?? uniqid()),
                    'name' => $s['site_name'] ?? '',
                    'desc' => $s['site_desc'] ?? '',
                    'link' => $s['site_url'] ?? '',
                    'sort' => $sort,
                    'category' => $catKey,
                    'hidden' => !empty($s['hidden']),
                    'user_email' => $s['user_email'] ?? '',
                    'contact' => $s['contact'] ?? '',
                    'submit_time' => $s['submit_time'] ?? '',
                    'audit_time' => $s['audit_time'] ?? '',
                    'submission_id' => $s['id'] ?? null
                ];
            }
            usort($out, function($a, $b) { return $a['sort'] - $b['sort']; });
            return $out;
        };

        if ($category !== '') {
            if (!in_array($category, $validCats, true)) {
                json_exit(['ok' => false, 'msg' => '分类不正确']);
            }
            json_exit(['ok' => true, 'data' => ['category' => $category, 'list' => $buildOneCategory($category)]]);
        }
        // 返回所有分类
        $all = [];
        foreach ($validCats as $k) $all[$k] = $buildOneCategory($k);
        json_exit(['ok' => true, 'data' => $all]);
        break;
    }

    // ========== 7.2 后台分类链接管理：新增 / 编辑 / 删除 / 取消隐藏 （统一接口）==========
    // op:
    //   create  - source=custom：在 categories[cat] 新增
    //   update  - custom：更新 categories；submission：更新 submissions 中的名称/描述/链接
    //   delete  - custom：从 categories 删除；submission：把 submissions 中 hidden=1（前台不再展示，分类管理仍可见为"已隐藏"）
    //   purge   - submission：真正从 submissions 删除（永久删除一条收录）
    //   unhide  - submission：取消 hidden=1
    case 'admin_manage_link': {
        $adminToken = $input['admin_token'] ?? '';
        if ($adminToken !== md5('hh_admin_2026')) {
            json_exit(['ok' => false, 'msg' => '无权限']);
        }
        $op = trim($input['op'] ?? '');
        $source = trim($input['source'] ?? 'custom'); // custom / submission
        $category = trim($input['category'] ?? '');
        $validCats = ['pay','server','dist','nav','login','blog','card','tool'];
        if (!in_array($category, $validCats, true)) json_exit(['ok' => false, 'msg' => '分类不正确']);
        if (!in_array($op, ['create','update','delete','purge','unhide'], true)) json_exit(['ok' => false, 'msg' => '操作类型不正确']);
        if (!in_array($source, ['custom','submission'], true)) json_exit(['ok' => false, 'msg' => '来源标识不正确']);

        $siteData = readJson($SITE_DATA_FILE);
        if (!isset($siteData['categories']) || !is_array($siteData['categories'])) $siteData['categories'] = [];
        $cats = &$siteData['categories'];
        if (!isset($cats[$category]) || !is_array($cats[$category])) $cats[$category] = [];

        // ===== source=custom：在site_data.categories上操作 =====
        if ($source === 'custom') {
            $id = isset($input['id']) ? (int)$input['id'] : 0;
            $name = trim($input['name'] ?? '');
            $desc = trim($input['desc'] ?? '');
            $link = trim($input['link'] ?? '');
            $sort = isset($input['sort']) ? (int)$input['sort'] : 0;
            if (in_array($op, ['create','update'], true)) {
                if ($name === '' || $link === '') json_exit(['ok' => false, 'msg' => '名称和链接不能为空']);
            }

            if ($op === 'create') {
                // 计算新id
                $maxId = 0;
                foreach ($cats[$category] as $c) if (is_array($c) && isset($c['id']) && (int)$c['id'] > $maxId) $maxId = (int)$c['id'];
                if ($sort <= 0) {
                    $maxSort = 0;
                    foreach ($cats[$category] as $c) if (is_array($c) && isset($c['sort']) && (int)$c['sort'] > $maxSort) $maxSort = (int)$c['sort'];
                    $sort = $maxSort + 1;
                }
                $cats[$category][] = ['id' => $maxId + 1, 'name' => $name, 'desc' => $desc, 'link' => $link, 'sort' => $sort];
                if (!writeJson($SITE_DATA_FILE, $siteData)) {
                    $_d = write_json_last_error();
                    json_exit(['ok' => false, 'msg' => '新增链接保存失败：' . ($_d ?: '请查看data/write_error.log')]);
                }
                json_exit(['ok' => true, 'msg' => '已新增链接', 'data' => ['id' => $maxId + 1]]);
            }
            if ($op === 'update') {
                if ($id <= 0) json_exit(['ok' => false, 'msg' => '链接ID缺失']);
                $found = false;
                foreach ($cats[$category] as &$c) {
                    if (is_array($c) && isset($c['id']) && (int)$c['id'] === $id) {
                        $c['name'] = $name; $c['desc'] = $desc; $c['link'] = $link;
                        if ($sort > 0) $c['sort'] = $sort;
                        $found = true; break;
                    }
                }
                unset($c);
                if (!$found) json_exit(['ok' => false, 'msg' => '未找到该自定义链接']);
                if (!writeJson($SITE_DATA_FILE, $siteData)) {
                    $_d = write_json_last_error();
                    json_exit(['ok' => false, 'msg' => '更新失败：' . ($_d ?: '请查看data/write_error.log')]);
                }
                json_exit(['ok' => true, 'msg' => '已更新']);
            }
            if ($op === 'delete') {
                if ($id <= 0) json_exit(['ok' => false, 'msg' => '链接ID缺失']);
                $before = count($cats[$category]);
                $cats[$category] = array_values(array_filter($cats[$category], function($c) use ($id) {
                    return is_array($c) && !(isset($c['id']) && (int)$c['id'] === $id);
                }));
                if (count($cats[$category]) === $before) json_exit(['ok' => false, 'msg' => '未找到该自定义链接']);
                if (!writeJson($SITE_DATA_FILE, $siteData)) {
                    $_d = write_json_last_error();
                    json_exit(['ok' => false, 'msg' => '删除失败：' . ($_d ?: '请查看data/write_error.log')]);
                }
                json_exit(['ok' => true, 'msg' => '已删除']);
            }
            json_exit(['ok' => false, 'msg' => '自定义链接不支持此操作：' . $op]);
        }

        // ===== source=submission：在submissions上操作 =====
        $submissionId = trim($input['submission_id'] ?? ($input['id'] ?? ''));
        // id 可能传的是 "sub_xxx" 这种，去掉前缀
        if (strpos($submissionId, 'sub_') === 0) $submissionId = substr($submissionId, 4);
        if ($submissionId === '') json_exit(['ok' => false, 'msg' => '收录ID缺失']);

        $submissions = readJson($SUBMISSIONS_FILE);
        $idx = null;
        foreach ($submissions as $i => $s) {
            if (is_array($s) && ($s['id'] ?? '') === $submissionId) { $idx = $i; break; }
        }
        if ($idx === null) json_exit(['ok' => false, 'msg' => '收录记录不存在']);

        if ($op === 'update') {
            $name = trim($input['name'] ?? '');
            $desc = trim($input['desc'] ?? '');
            $link = trim($input['link'] ?? '');
            if ($name === '' || $link === '') json_exit(['ok' => false, 'msg' => '名称和链接不能为空']);
            $submissions[$idx]['site_name'] = $name;
            $submissions[$idx]['site_desc'] = $desc;
            $submissions[$idx]['site_url']  = $link;
            $newCat = trim($input['category_new'] ?? '');
            if (in_array($newCat, $validCats, true)) $submissions[$idx]['category'] = $newCat;
            if (!writeJson($SUBMISSIONS_FILE, $submissions)) {
                $_d = write_json_last_error();
                json_exit(['ok' => false, 'msg' => '收录信息更新失败：' . ($_d ?: '请查看data/write_error.log')]);
            }
            json_exit(['ok' => true, 'msg' => '已更新收录信息']);
        }
        if ($op === 'delete') {
            // 管理员从分类链接管理里删除一条收录：不是真删除，而是标记hidden=1，前台不再展示，分类管理里还能恢复
            $submissions[$idx]['hidden'] = true;
            $submissions[$idx]['hidden_at'] = date('Y-m-d H:i:s');
            if (!writeJson($SUBMISSIONS_FILE, $submissions)) {
                $_d = write_json_last_error();
                json_exit(['ok' => false, 'msg' => '隐藏收录失败：' . ($_d ?: '请查看data/write_error.log')]);
            }
            json_exit(['ok' => true, 'msg' => '已从前台移除（在分类管理中可随时恢复展示）']);
        }
        if ($op === 'unhide') {
            unset($submissions[$idx]['hidden']);
            unset($submissions[$idx]['hidden_at']);
            if (!writeJson($SUBMISSIONS_FILE, $submissions)) {
                $_d = write_json_last_error();
                json_exit(['ok' => false, 'msg' => '恢复展示失败：' . ($_d ?: '请查看data/write_error.log')]);
            }
            json_exit(['ok' => true, 'msg' => '已恢复前台展示']);
        }
        if ($op === 'purge') {
            array_splice($submissions, $idx, 1);
            if (!writeJson($SUBMISSIONS_FILE, $submissions)) {
                $_d = write_json_last_error();
                json_exit(['ok' => false, 'msg' => '永久删除失败：' . ($_d ?: '请查看data/write_error.log')]);
            }
            json_exit(['ok' => true, 'msg' => '已永久删除该收录记录']);
        }
        json_exit(['ok' => false, 'msg' => '收录记录不支持此操作：' . $op]);
        break;
    }

    // ========== 8. 获取所有收录列表（后台用） ==========
    case 'admin_submissions':
        $adminToken = $input['admin_token'] ?? '';
        if ($adminToken !== md5('hh_admin_2026')) {
            json_exit(['ok' => false, 'msg' => '无权限']);
        }
        $status = $input['status'] ?? 'all';
        $submissions = readJson($SUBMISSIONS_FILE);
        if ($status !== 'all') {
            $submissions = array_filter($submissions, function($s) use ($status) {
                return $s['status'] === $status;
            });
        }
        // 按时间倒序
        usort($submissions, function($a, $b) {
            return strcmp($b['submit_time'], $a['submit_time']);
        });
        json_exit(['ok' => true, 'data' => array_values($submissions)]);
        break;

    // ========== 9. 审核收录（后台用） ==========
    case 'audit_site':
        $adminToken = $input['admin_token'] ?? '';
        if ($adminToken !== md5('hh_admin_2026')) {
            json_exit(['ok' => false, 'msg' => '无权限']);
        }
        $id = $input['id'] ?? '';
        $auditStatus = $input['audit_status'] ?? ''; // approved / rejected
        $auditRemark = trim($input['audit_remark'] ?? '');

        if (!in_array($auditStatus, ['approved', 'rejected'])) {
            json_exit(['ok' => false, 'msg' => '审核状态不正确']);
        }

        $submissions = readJson($SUBMISSIONS_FILE);
        $found = false;
        foreach ($submissions as &$s) {
            if ($s['id'] === $id) {
                $s['status'] = $auditStatus;
                $s['audit_time'] = date('Y-m-d H:i:s');
                $s['audit_remark'] = $auditRemark;
                $found = true;
                break;
            }
        }
        unset($s);

        if (!$found) {
            json_exit(['ok' => false, 'msg' => '记录不存在']);
        }
        if (!writeJson($SUBMISSIONS_FILE, $submissions)) {
            $_detail = write_json_last_error();
            json_exit(['ok' => false, 'msg' => '审核结果保存失败：' . ($_detail ?: '请检查data目录写入权限，可查看data/write_error.log')]);
        }
        json_exit(['ok' => true, 'msg' => $auditStatus === 'approved' ? '已审核通过，该网站将展示在前台' : '已拒绝该收录申请']);
        break;

    // ========== 10. 获取用户列表（后台用） ==========
    case 'admin_users':
        $adminToken = $input['admin_token'] ?? '';
        if ($adminToken !== md5('hh_admin_2026')) {
            json_exit(['ok' => false, 'msg' => '无权限']);
        }
        $users = readJson($USERS_FILE);
        // 脱敏密码
        $users = array_map(function($u) {
            unset($u['password']);
            return $u;
        }, $users);
        usort($users, function($a, $b) {
            return strcmp($b['register_time'], $a['register_time']);
        });
        json_exit(['ok' => true, 'data' => array_values($users)]);
        break;

    // ========== 11. 获取收录统计（后台用） ==========
    case 'admin_stats':
        $adminToken = $input['admin_token'] ?? '';
        if ($adminToken !== md5('hh_admin_2026')) {
            json_exit(['ok' => false, 'msg' => '无权限']);
        }
        $users = readJson($USERS_FILE);
        $submissions = readJson($SUBMISSIONS_FILE);
        $pending = count(array_filter($submissions, fn($s) => $s['status'] === 'pending'));
        $approved = count(array_filter($submissions, fn($s) => $s['status'] === 'approved'));
        $rejected = count(array_filter($submissions, fn($s) => $s['status'] === 'rejected'));
        json_exit(['ok' => true, 'data' => [
            'users' => count($users),
            'submissions' => count($submissions),
            'pending' => $pending,
            'approved' => $approved,
            'rejected' => $rejected
        ]]);
        break;

    // ========== 12. 删除收录记录（后台用） ==========
    case 'admin_delete_submission':
        $adminToken = $input['admin_token'] ?? '';
        if ($adminToken !== md5('hh_admin_2026')) {
            json_exit(['ok' => false, 'msg' => '无权限']);
        }
        $id = $input['id'] ?? '';
        $submissions = readJson($SUBMISSIONS_FILE);
        $submissions = array_filter($submissions, fn($s) => $s['id'] !== $id);
        if (!writeJson($SUBMISSIONS_FILE, array_values($submissions))) {
            $_detail = write_json_last_error();
            json_exit(['ok' => false, 'msg' => '收录删除保存失败：' . ($_detail ?: '请检查data目录写入权限，可查看data/write_error.log')]);
        }
        json_exit(['ok' => true, 'msg' => '已删除']);
        break;

    // ============================================================
    // ========== 第三部分：广告位招租 + 支付宝当面付 ==========
    // ============================================================

    // ========== 13. 获取广告位配置（前台公开） ==========
    case 'ad_slots':
        $slots = readJson($AD_SLOTS_FILE);
        if (empty($slots)) $slots = AdHelper::defaultSlots();
        // 隐藏敏感字段，只保留展示需要的
        $result = [];
        foreach ($slots as $key => $s) {
            if (empty($s['enabled'])) continue;
            $result[] = [
                'key' => $key,
                'name' => $s['name'],
                'desc' => $s['desc'] ?? '',
                'size' => $s['size'] ?? '',
                'plans' => $s['plans'] ?? []
            ];
        }
        json_exit(['ok' => true, 'data' => $result]);
        break;

    // ========== 14. 后台获取广告位配置（含未启用） ==========
    case 'admin_ad_slots':
        if (($input['admin_token'] ?? '') !== md5('hh_admin_2026')) {
            json_exit(['ok' => false, 'msg' => '无权限']);
        }
        $slots = readJson($AD_SLOTS_FILE);
        if (empty($slots)) $slots = AdHelper::defaultSlots();
        json_exit(['ok' => true, 'data' => $slots]);
        break;

    // ========== 15. 后台保存广告位配置 ==========
    case 'admin_save_ad_slots':
        if (($input['admin_token'] ?? '') !== md5('hh_admin_2026')) {
            json_exit(['ok' => false, 'msg' => '无权限']);
        }
        $slots = $input['slots'] ?? [];
        if (!is_array($slots)) json_exit(['ok' => false, 'msg' => '数据格式错误']);
        // 清洗保留字段
        $clean = [];
        foreach ($slots as $key => $s) {
            $key = preg_replace('/[^a-zA-Z0-9_]/', '', $key);
            if (!$key) continue;
            $clean[$key] = [
                'name' => trim($s['name'] ?? ''),
                'desc' => trim($s['desc'] ?? ''),
                'size' => trim($s['size'] ?? ''),
                'enabled' => !empty($s['enabled']),
                'plans' => [
                    'month'   => ['name' => '月卡', 'price' => floatval($s['plans']['month']['price'] ?? 0),   'days' => 30],
                    'quarter' => ['name' => '季卡', 'price' => floatval($s['plans']['quarter']['price'] ?? 0), 'days' => 90],
                    'year'    => ['name' => '年卡', 'price' => floatval($s['plans']['year']['price'] ?? 0),    'days' => 365]
                ]
            ];
        }
        writeJson($AD_SLOTS_FILE, $clean);
        json_exit(['ok' => true, 'msg' => '广告位配置已保存']);
        break;

    // ========== 16. 用户下单（创建支付宝当面付预订单） ==========
    case 'create_ad_order':
        $session = checkUserSession($input['token'] ?? '');
        if (!$session) json_exit(['ok' => false, 'msg' => '请先登录']);
        $email = $session['email'];

        $slotKey = trim($input['slot_key'] ?? '');
        $plan    = trim($input['plan'] ?? ''); // month / quarter / year
        $title   = trim($input['title'] ?? '');
        $link    = trim($input['link'] ?? '');
        $image   = trim($input['image'] ?? '');

        $slots = readJson($AD_SLOTS_FILE);
        if (empty($slots)) $slots = AdHelper::defaultSlots();
        if (!isset($slots[$slotKey]) || empty($slots[$slotKey]['enabled'])) {
            json_exit(['ok' => false, 'msg' => '广告位不存在或已下架']);
        }
        if (!isset($slots[$slotKey]['plans'][$plan])) {
            json_exit(['ok' => false, 'msg' => '套餐不存在']);
        }
        if (mb_strlen($title) < 2) json_exit(['ok' => false, 'msg' => '请填写广告标题（至少2字）']);
        if (!filter_var($link, FILTER_VALIDATE_URL)) json_exit(['ok' => false, 'msg' => '请填写合法的广告链接']);
        if (!filter_var($image, FILTER_VALIDATE_URL)) json_exit(['ok' => false, 'msg' => '请填写合法的图片地址']);

        $slot = $slots[$slotKey];
        $planInfo = $slot['plans'][$plan];
        $price = $planInfo['price'];
        if ($price <= 0) json_exit(['ok' => false, 'msg' => '该套餐未配置价格，请联系管理员']);
        $days = $planInfo['days'];

        $orderId = 'AD' . date('YmdHis') . sprintf('%03d', rand(0, 999));
        $orders = readJson($AD_ORDERS_FILE);

        // 创建订单记录
        $newOrder = [
            'id' => $orderId,
            'user_email' => $email,
            'slot_key' => $slotKey,
            'slot_name' => $slot['name'],
            'plan' => $plan,
            'plan_name' => $planInfo['name'],
            'days' => $days,
            'price' => $price,
            'title' => $title,
            'link' => $link,
            'image' => $image,
            'status' => 'pending',
            'create_time' => date('Y-m-d H:i:s'),
            'pay_time' => '',
            'expire_time' => '',
            'trade_no' => ''
        ];
        $orders[] = $newOrder;
        writeJson($AD_ORDERS_FILE, $orders);

        // 调用支付宝当面付预下单
        $subject = $slot['name'] . ' - ' . $planInfo['name'] . ' [' . $orderId . ']';
        $result = AlipayFacePay::precreate($orderId, $price, $subject);
        if (!$result['ok']) {
            json_exit(['ok' => false, 'msg' => $result['msg'] ?? '支付宝下单失败']);
        }

        json_exit(['ok' => true, 'data' => [
            'order_id' => $orderId,
            'qr_code' => $result['qr_code'],
            'price' => $price,
            'subject' => $subject
        ]]);
        break;

    // ========== 17. 查询订单支付状态 ==========
    case 'query_ad_order':
        $session = checkUserSession($input['token'] ?? '');
        if (!$session) json_exit(['ok' => false, 'msg' => '请先登录']);
        $orderId = trim($input['order_id'] ?? '');
        $orders = readJson($AD_ORDERS_FILE);
        $order = null;
        foreach ($orders as &$o) {
            if ($o['id'] === $orderId) { $order = &$o; break; }
        }
        if (!$order) json_exit(['ok' => false, 'msg' => '订单不存在']);
        if ($order['user_email'] !== $session['email']) {
            json_exit(['ok' => false, 'msg' => '无权查看此订单']);
        }
        // 已支付的直接返回
        if ($order['status'] === 'paid') {
            json_exit(['ok' => true, 'data' => ['status' => 'paid', 'expire_time' => $order['expire_time']]]);
        }
        // 已取消
        if ($order['status'] === 'cancelled') {
            json_exit(['ok' => true, 'data' => ['status' => 'cancelled']]);
        }
        // 超时自动取消（30分钟未支付）
        $createTs = strtotime($order['create_time']);
        if (time() - $createTs > 1800) {
            $order['status'] = 'cancelled';
            writeJson($AD_ORDERS_FILE, $orders);
            json_exit(['ok' => true, 'data' => ['status' => 'cancelled']]);
        }
        // 主动查询支付宝
        $queryRes = AlipayFacePay::query($orderId);
        if ($queryRes['ok'] && $queryRes['trade_status'] === 'TRADE_SUCCESS') {
            // 支付成功，激活订单
            $order['status'] = 'paid';
            $order['trade_no'] = $queryRes['trade_no'];
            $order['pay_time'] = date('Y-m-d H:i:s');
            $order['expire_time'] = date('Y-m-d H:i:s', time() + $order['days'] * 86400);
            writeJson($AD_ORDERS_FILE, $orders);
            json_exit(['ok' => true, 'data' => ['status' => 'paid', 'expire_time' => $order['expire_time']]]);
        }
        json_exit(['ok' => true, 'data' => ['status' => 'pending']]);
        break;

    // ========== 18. 用户查看自己的广告订单 ==========
    case 'user_ad_orders':
        $session = checkUserSession($input['token'] ?? '');
        if (!$session) json_exit(['ok' => false, 'msg' => '请先登录']);
        $email = $session['email'];
        $orders = readJson($AD_ORDERS_FILE);
        $mine = array_values(array_filter($orders, fn($o) => $o['user_email'] === $email));
        usort($mine, fn($a, $b) => strcmp($b['create_time'], $a['create_time']));
        json_exit(['ok' => true, 'data' => $mine]);
        break;

    // ========== 19. 取消未支付订单 ==========
    case 'cancel_ad_order':
        $session = checkUserSession($input['token'] ?? '');
        if (!$session) json_exit(['ok' => false, 'msg' => '请先登录']);
        $orderId = trim($input['order_id'] ?? '');
        $orders = readJson($AD_ORDERS_FILE);
        foreach ($orders as &$o) {
            if ($o['id'] === $orderId && $o['user_email'] === $session['email']) {
                if ($o['status'] === 'pending') {
                    $o['status'] = 'cancelled';
                    writeJson($AD_ORDERS_FILE, $orders);
                    json_exit(['ok' => true, 'msg' => '订单已取消']);
                }
                json_exit(['ok' => false, 'msg' => '当前状态不可取消']);
            }
        }
        json_exit(['ok' => false, 'msg' => '订单不存在']);
        break;

    // ========== 20. 用户续费订单（已支付订单续费） ==========
    case 'renew_ad_order':
        $session = checkUserSession($input['token'] ?? '');
        if (!$session) json_exit(['ok' => false, 'msg' => '请先登录']);
        $orderId = trim($input['order_id'] ?? '');
        $plan = trim($input['plan'] ?? '');
        $orders = readJson($AD_ORDERS_FILE);
        $origin = null;
        foreach ($orders as $o) {
            if ($o['id'] === $orderId && $o['user_email'] === $session['email']) {
                $origin = $o; break;
            }
        }
        if (!$origin) json_exit(['ok' => false, 'msg' => '订单不存在']);
        if ($origin['status'] !== 'paid') json_exit(['ok' => false, 'msg' => '请先支付原订单']);
        $slots = readJson($AD_SLOTS_FILE);
        if (empty($slots)) $slots = AdHelper::defaultSlots();
        $slot = $slots[$origin['slot_key']] ?? null;
        if (!$slot) json_exit(['ok' => false, 'msg' => '广告位已下架']);
        if (!isset($slot['plans'][$plan])) json_exit(['ok' => false, 'msg' => '套餐不存在']);
        $planInfo = $slot['plans'][$plan];

        $newOrderId = 'AD' . date('YmdHis') . sprintf('%03d', rand(0, 999));
        $newOrder = [
            'id' => $newOrderId,
            'user_email' => $session['email'],
            'slot_key' => $origin['slot_key'],
            'slot_name' => $origin['slot_name'],
            'plan' => $plan,
            'plan_name' => $planInfo['name'],
            'days' => $planInfo['days'],
            'price' => $planInfo['price'],
            'title' => $origin['title'],
            'link' => $origin['link'],
            'image' => $origin['image'],
            'status' => 'pending',
            'create_time' => date('Y-m-d H:i:s'),
            'pay_time' => '',
            'expire_time' => '',
            'trade_no' => '',
            'renew_of' => $orderId
        ];
        $orders[] = $newOrder;
        writeJson($AD_ORDERS_FILE, $orders);

        $subject = $origin['slot_name'] . ' - ' . $planInfo['name'] . ' [续费 ' . $newOrderId . ']';
        $result = AlipayFacePay::precreate($newOrderId, $planInfo['price'], $subject);
        if (!$result['ok']) json_exit(['ok' => false, 'msg' => $result['msg']]);

        json_exit(['ok' => true, 'data' => [
            'order_id' => $newOrderId,
            'qr_code' => $result['qr_code'],
            'price' => $planInfo['price'],
            'subject' => $subject
        ]]);
        break;

    // ========== 21. 后台获取所有广告订单 ==========
    case 'admin_ad_orders':
        if (($input['admin_token'] ?? '') !== md5('hh_admin_2026')) {
            json_exit(['ok' => false, 'msg' => '无权限']);
        }
        $status = $input['status'] ?? 'all';
        $orders = readJson($AD_ORDERS_FILE);
        if ($status !== 'all') {
            $orders = array_values(array_filter($orders, fn($o) => $o['status'] === $status));
        }
        usort($orders, fn($a, $b) => strcmp($b['create_time'], $a['create_time']));
        json_exit(['ok' => true, 'data' => $orders]);
        break;

    // ========== 22. 后台删除订单 ==========
    case 'admin_delete_ad_order':
        if (($input['admin_token'] ?? '') !== md5('hh_admin_2026')) {
            json_exit(['ok' => false, 'msg' => '无权限']);
        }
        $orderId = $input['order_id'] ?? '';
        $orders = readJson($AD_ORDERS_FILE);
        $orders = array_values(array_filter($orders, fn($o) => $o['id'] !== $orderId));
        writeJson($AD_ORDERS_FILE, $orders);
        json_exit(['ok' => true, 'msg' => '已删除']);
        break;

    // ========== 23. 前台获取已支付的广告（自动注入展示） ==========
    case 'active_ads':
        $orders = readJson($AD_ORDERS_FILE);
        $now = time();
        $active = [];
        $hasExpired = false;
        foreach ($orders as $k => &$o) {
            if (($o['status'] ?? '') !== 'paid') continue;
            $expireTs = strtotime($o['expire_time'] ?? '');
            if (!$expireTs || $expireTs < $now) {
                // 已到期（或缺少到期时间但 status=paid），自动标记为 expired
                if (($o['status'] ?? '') === 'paid' && $expireTs && $expireTs < $now) {
                    $o['status'] = 'expired';
                    $hasExpired = true;
                }
                continue;
            }
            $active[] = [
                'slot_key' => $o['slot_key'],
                'title' => $o['title'],
                'link' => $o['link'],
                'image' => $o['image'],
                'expire_time' => $o['expire_time']
            ];
        }
        unset($o);
        if ($hasExpired) {
            writeJson($AD_ORDERS_FILE, $orders);
        }
        json_exit(['ok' => true, 'data' => $active]);
        break;

    // ========== 24. 后台获取指定广告位的付费广告列表（含已到期/未到期） ==========
    case 'admin_paid_ads':
        if (($input['admin_token'] ?? '') !== md5('hh_admin_2026')) {
            json_exit(['ok' => false, 'msg' => '无权限']);
        }
        $slotKey = trim($input['slot_key'] ?? ''); // banner_top / grid_home / ''(全部)
        $includeExpired = !($input['hide_expired'] ?? false);
        $orders = readJson($AD_ORDERS_FILE);
        $now = time();
        $result = [];
        foreach ($orders as $o) {
            if ($o['status'] !== 'paid') continue; // 只展示已支付的订单（未支付/已取消不展示）
            if ($slotKey && ($o['slot_key'] ?? '') !== $slotKey) continue;
            $expireTs = strtotime($o['expire_time'] ?? '');
            $isExpired = $expireTs && $expireTs < $now;
            if (!$includeExpired && $isExpired) continue;
            $result[] = [
                'order_id'    => $o['id'],
                'slot_key'    => $o['slot_key'],
                'slot_name'   => $o['slot_name'],
                'title'       => $o['title'],
                'link'        => $o['link'],
                'image'       => $o['image'],
                'price'       => $o['price'],
                'plan_name'   => $o['plan_name'],
                'days'        => $o['days'],
                'user_email'  => $o['user_email'],
                'create_time' => $o['create_time'],
                'pay_time'    => $o['pay_time'],
                'expire_time' => $o['expire_time'],
                'expired'     => $isExpired,
                'trade_no'    => $o['trade_no'] ?? ''
            ];
        }
        // 未过期的排前面
        usort($result, function($a, $b) {
            if ($a['expired'] !== $b['expired']) return $a['expired'] ? 1 : -1;
            return strcmp($b['pay_time'] ?? '', $a['pay_time'] ?? '');
        });
        json_exit(['ok' => true, 'data' => $result]);
        break;

    // ========== 25. 后台删除付费广告（按订单ID，物理删除订单记录） ==========
    case 'admin_delete_paid_ad':
        if (($input['admin_token'] ?? '') !== md5('hh_admin_2026')) {
            json_exit(['ok' => false, 'msg' => '无权限']);
        }
        $orderId = trim($input['order_id'] ?? '');
        if (!$orderId) json_exit(['ok' => false, 'msg' => '缺少 order_id']);
        $orders = readJson($AD_ORDERS_FILE);
        $before = count($orders);
        $orders = array_values(array_filter($orders, fn($o) => ($o['id'] ?? '') !== $orderId));
        if (count($orders) === $before) json_exit(['ok' => false, 'msg' => '广告订单不存在']);
        writeJson($AD_ORDERS_FILE, $orders);
        json_exit(['ok' => true, 'msg' => '付费广告已删除']);
        break;

    // ========== 25.5 后台修改付费广告到期时间 ==========
    case 'admin_update_paid_ad_expire':
        if (($input['admin_token'] ?? '') !== md5('hh_admin_2026')) {
            json_exit(['ok' => false, 'msg' => '无权限']);
        }
        $orderId  = trim($input['order_id'] ?? '');
        $expireTs = trim($input['expire_ts'] ?? ''); // 新到期时间戳（秒）
        if (!$orderId || !$expireTs) json_exit(['ok' => false, 'msg' => '缺少参数']);
        $expireTs = (int)$expireTs;
        if ($expireTs <= time()) json_exit(['ok' => false, 'msg' => '到期时间必须晚于当前时间']);
        $orders = readJson($AD_ORDERS_FILE);
        $found = false;
        foreach ($orders as &$o) {
            if (($o['id'] ?? '') === $orderId) {
                $o['expire_time'] = date('Y-m-d H:i:s', $expireTs);
                $o['status'] = 'paid'; // 编辑到期时间后恢复为 paid 状态（若之前为 expired）
                $found = true;
                break;
            }
        }
        unset($o);
        if (!$found) json_exit(['ok' => false, 'msg' => '广告订单不存在']);
        writeJson($AD_ORDERS_FILE, $orders);
        json_exit(['ok' => true, 'msg' => '到期时间已更新']);
        break;

    // ========== 26. 后台清理到期广告（将已到期的 paid 订单标记为 expired，前台自动不展示） ==========
    case 'admin_cleanup_expired_ads':
        if (($input['admin_token'] ?? '') !== md5('hh_admin_2026')) {
            json_exit(['ok' => false, 'msg' => '无权限']);
        }
        $orders = readJson($AD_ORDERS_FILE);
        $now = time();
        $cleaned = 0;
        foreach ($orders as &$o) {
            if (($o['status'] ?? '') !== 'paid') continue;
            $expireTs = strtotime($o['expire_time'] ?? '');
            if ($expireTs && $expireTs < $now) {
                $o['status'] = 'expired';
                $cleaned++;
            }
        }
        unset($o);
        writeJson($AD_ORDERS_FILE, $orders);
        json_exit(['ok' => true, 'msg' => "已清理 {$cleaned} 条到期广告", 'data' => ['cleaned' => $cleaned]]);
        break;

    // ========== 27. 前台获取站点配置（轮播广告、图文广告、分类链接）—— 无需鉴权，PC/手机端共用 ==========
    case 'get_site_data':
        $siteData = readJson($SITE_DATA_FILE);
        json_exit(['ok' => true, 'data' => $siteData]);
        break;

    // ========== 28. 后台同步站点配置到服务器（每次 setStorage 时自动调用） ==========
    case 'admin_sync_site_data':
        if (($input['admin_token'] ?? '') !== md5('hh_admin_2026')) {
            json_exit(['ok' => false, 'msg' => '无权限']);
        }
        $payload = $input['data'] ?? [];
        // 仅允许已知字段，防止脏数据
        $allowed = ['settings', 'banner_ads', 'grid_ads', 'categories'];
        $clean = [];
        foreach ($allowed as $k) {
            if (isset($payload[$k])) $clean[$k] = $payload[$k];
        }
        if (empty($clean)) {
            json_exit(['ok' => false, 'msg' => '无有效数据']);
        }
        // 合并已有数据（支持局部更新）
        $existing = readJson($SITE_DATA_FILE);
        $merged = array_merge($existing, $clean);
        writeJson($SITE_DATA_FILE, $merged);
        json_exit(['ok' => true, 'msg' => '同步成功']);
        break;

    // ========== 29. 后台读取支付宝当面付密钥配置 ==========
    case 'admin_get_alipay_config':
        if (($input['admin_token'] ?? '') !== md5('hh_admin_2026')) {
            json_exit(['ok' => false, 'msg' => '无权限']);
        }
        AlipayFacePay::init(); // 触发迁移（若需要）
        $cfg = readJson($ALIPAY_CONFIG_FILE);
        // 私钥和公钥返回给后台用于显示/编辑；如果是空的，提示管理员填写
        $out = [
            'app_id'            => $cfg['app_id']            ?? '',
            'app_private_key'   => $cfg['app_private_key']   ?? '',
            'alipay_public_key' => $cfg['alipay_public_key'] ?? '',
            'updated_at'        => $cfg['updated_at']        ?? ($cfg['migrated_at'] ?? '')
        ];
        json_exit(['ok' => true, 'data' => $out]);
        break;

    // ========== 30. 后台保存支付宝当面付密钥配置 ==========
    case 'admin_save_alipay_config':
        if (($input['admin_token'] ?? '') !== md5('hh_admin_2026')) {
            json_exit(['ok' => false, 'msg' => '无权限']);
        }
        $appId       = trim($input['app_id'] ?? '');
        $privateKey  = trim($input['app_private_key'] ?? '');
        $publicKey   = trim($input['alipay_public_key'] ?? '');
        if ($appId === '' || $privateKey === '' || $publicKey === '') {
            json_exit(['ok' => false, 'msg' => '应用ID、应用私钥、支付宝公钥均不能为空']);
        }
        // 基本格式校验（非严格，只是初步防止乱填）
        if (!preg_match('/^20\d{14,}$/', $appId)) {
            json_exit(['ok' => false, 'msg' => '应用ID格式不正确（一般为 2021/2024 开头的16位数字）']);
        }
        if (strpos($privateKey, 'BEGIN PRIVATE KEY') !== false || strpos($privateKey, 'BEGIN RSA PRIVATE KEY') !== false) {
            // 用户如果粘贴了带 PEM 头的，提取纯 base64 部分
            $privateKey = preg_replace('/-----BEGIN (RSA )?PRIVATE KEY-----/', '', $privateKey);
            $privateKey = preg_replace('/-----END (RSA )?PRIVATE KEY-----/', '', $privateKey);
            $privateKey = preg_replace('/\s+/', '', $privateKey);
        }
        if (strpos($publicKey, 'BEGIN PUBLIC KEY') !== false) {
            $publicKey = preg_replace('/-----BEGIN PUBLIC KEY-----/', '', $publicKey);
            $publicKey = preg_replace('/-----END PUBLIC KEY-----/', '', $publicKey);
            $publicKey = preg_replace('/\s+/', '', $publicKey);
        }
        if (!preg_match('/^[A-Za-z0-9\/+=]+$/', $privateKey)) {
            json_exit(['ok' => false, 'msg' => '应用私钥格式不正确（应为 base64 字符串，不含PEM头）']);
        }
        if (!preg_match('/^[A-Za-z0-9\/+=]+$/', $publicKey)) {
            json_exit(['ok' => false, 'msg' => '支付宝公钥格式不正确（应为 base64 字符串，不含PEM头）']);
        }
        $save = [
            'app_id'            => $appId,
            'app_private_key'   => $privateKey,
            'alipay_public_key' => $publicKey,
            'updated_at'        => date('Y-m-d H:i:s')
        ];
        writeJson($ALIPAY_CONFIG_FILE, $save);
        // 重置 AlipayFacePay 内部缓存，本次请求后续就能用新配置
        AlipayFacePay::resetStatic();
        json_exit(['ok' => true, 'msg' => '支付宝配置已保存']);
        break;

    // ========== 31. 后台读取邮箱SMTP配置 ==========
    case 'admin_get_email_config':
        if (($input['admin_token'] ?? '') !== md5('hh_admin_2026')) {
            json_exit(['ok' => false, 'msg' => '无权限']);
        }
        $cfg = getEmailConfig(); // 触发首次迁移（如需要）
        $out = [
            'smtp_host'   => $cfg['smtp_host']   ?? '',
            'smtp_port'   => isset($cfg['smtp_port']) ? intval($cfg['smtp_port']) : 465,
            'smtp_secure' => $cfg['smtp_secure'] ?? 'ssl', // ssl / tls / none
            'smtp_user'   => $cfg['smtp_user']   ?? '',
            'smtp_pass'   => $cfg['smtp_pass']   ?? '',
            'sender_name' => $cfg['sender_name'] ?? '',
            'site_name'   => $cfg['site_name']   ?? '',
            'test_email'  => $cfg['test_email']  ?? '',
            'updated_at'  => $cfg['updated_at']  ?? ($cfg['migrated_at'] ?? '')
        ];
        json_exit(['ok' => true, 'data' => $out]);
        break;

    // ========== 32. 后台保存邮箱SMTP配置（支持可选测试发送）==========
    case 'admin_save_email_config':
        if (($input['admin_token'] ?? '') !== md5('hh_admin_2026')) {
            json_exit(['ok' => false, 'msg' => '无权限']);
        }
        $host  = trim($input['smtp_host'] ?? '');
        $port  = intval($input['smtp_port'] ?? 465);
        $secure= trim($input['smtp_secure'] ?? 'ssl');
        $user  = trim($input['smtp_user'] ?? '');
        $pass  = trim($input['smtp_pass'] ?? '');
        $sName = trim($input['sender_name'] ?? '');
        $site  = trim($input['site_name']   ?? '');
        if ($host === '' || $user === '' || $pass === '') {
            json_exit(['ok' => false, 'msg' => 'SMTP服务器、发信账号、发信密码均不能为空']);
        }
        if ($port <= 0 || $port > 65535) {
            json_exit(['ok' => false, 'msg' => 'SMTP端口范围不正确']);
        }
        if (!in_array($secure, ['ssl', 'tls', 'none'], true)) {
            $secure = 'ssl';
        }
        if ($site === '') $site = $sName ?: '欢欢云导航';
        if (!filter_var($user, FILTER_VALIDATE_EMAIL)) {
            // 某些SMTP用户名就是邮箱地址，仅作格式提示
        }
        $save = [
            'smtp_host'   => $host,
            'smtp_port'   => $port,
            'smtp_secure' => $secure,
            'smtp_user'   => $user,
            'smtp_pass'   => $pass,
            'sender_name' => $sName,
            'site_name'   => $site,
            'updated_at'  => date('Y-m-d H:i:s')
        ];
        writeJson($EMAIL_CONFIG_FILE, $save);

        // 可选：立即发送测试邮件
        $testTo = trim($input['test_to_email'] ?? '');
        $testMsg = '';
        if ($testTo !== '' && filter_var($testTo, FILTER_VALIDATE_EMAIL)) {
            try {
                $testSubject = 'SMTP 配置测试';
                $testHtml = "<div style='max-width:480px;margin:0 auto;font-family:sans-serif;'>
                    <h3 style='color:#2563eb;margin-bottom:10px;'>邮箱配置测试成功 🎉</h3>
                    <p>这是一封来自后台 SMTP 配置页的测试邮件，说明您填写的 SMTP 服务器、账号、密码均正确。</p>
                    <p style='color:#999;font-size:12px;margin-top:30px;border-top:1px solid #f0f0f0;padding-top:15px;'>发送时间：" . date('Y-m-d H:i:s') . "</p>
                </div>";
                $mailer = new SmtpMail($host, $port, $user, $pass);
                $prefix = $site ? ('[' . $site . '] ') : '';
                $mailer->send($testTo, $prefix . $testSubject, $testHtml);
                $testMsg = '，测试邮件已发往 ' . $testTo;
            } catch (Exception $e) {
                json_exit(['ok' => false, 'msg' => '配置已保存，但测试邮件发送失败：' . $e->getMessage()]);
            }
        }
        json_exit(['ok' => true, 'msg' => '邮箱SMTP配置已保存' . $testMsg]);
        break;

    // ========== 33. 后台读取备案号配置 ==========
    case 'admin_get_icp_config':
        if (($input['admin_token'] ?? '') !== md5('hh_admin_2026')) {
            json_exit(['ok' => false, 'msg' => '无权限']);
        }
        $cfg = readJson($ICP_CONFIG_FILE);
        $out = [
            'icp_number'       => $cfg['icp_number']       ?? '',
            'icp_link'         => $cfg['icp_link']         ?? 'https://beian.miit.gov.cn/',
            'police_number'    => $cfg['police_number']    ?? '',
            'police_link'      => $cfg['police_link']      ?? '',
            'copyright_text'   => $cfg['copyright_text']   ?? '',
            'custom_footer'    => $cfg['custom_footer']    ?? '',
            'updated_at'       => $cfg['updated_at']       ?? ''
        ];
        json_exit(['ok' => true, 'data' => $out]);
        break;

    // ========== 34. 后台保存备案号配置 ==========
    case 'admin_save_icp_config':
        if (($input['admin_token'] ?? '') !== md5('hh_admin_2026')) {
            json_exit(['ok' => false, 'msg' => '无权限']);
        }
        $icpNumber   = trim($input['icp_number']     ?? '');
        $icpLink     = trim($input['icp_link']       ?? '');
        $policeNum   = trim($input['police_number']  ?? '');
        $policeLink  = trim($input['police_link']    ?? '');
        $copyright   = trim($input['copyright_text'] ?? '');
        $custom      = trim($input['custom_footer']  ?? '');
        // 基本校验
        if ($icpNumber !== '' && !preg_match('/^[\x{4e00}-\x{9fa5}A-Za-z0-9\-]+$/u', $icpNumber)) {
            json_exit(['ok' => false, 'msg' => 'ICP备案号格式不正确（仅支持中文、字母、数字、横杠）']);
        }
        if ($policeNum !== '' && !preg_match('/^[\x{4e00}-\x{9fa5}A-Za-z0-9\-]+$/u', $policeNum)) {
            json_exit(['ok' => false, 'msg' => '公安备案号格式不正确']);
        }
        if ($icpLink !== '' && !filter_var($icpLink, FILTER_VALIDATE_URL)) {
            json_exit(['ok' => false, 'msg' => 'ICP备案链接格式不正确（需以 http:// 或 https:// 开头）']);
        }
        if ($policeLink !== '' && !filter_var($policeLink, FILTER_VALIDATE_URL)) {
            json_exit(['ok' => false, 'msg' => '公安备案链接格式不正确（需以 http:// 或 https:// 开头）']);
        }
        if ($icpLink === '' && $icpNumber !== '') {
            $icpLink = 'https://beian.miit.gov.cn/';
        }
        $save = [
            'icp_number'     => $icpNumber,
            'icp_link'       => $icpLink,
            'police_number'  => $policeNum,
            'police_link'    => $policeLink,
            'copyright_text' => $copyright,
            'custom_footer'  => $custom,
            'updated_at'     => date('Y-m-d H:i:s')
        ];
        writeJson($ICP_CONFIG_FILE, $save);
        json_exit(['ok' => true, 'msg' => '备案号配置已保存']);
        break;

    // ========== 前台读取备案号配置（无需鉴权） ==========
    case 'get_icp_config':
        $cfg = readJson($ICP_CONFIG_FILE);
        $out = [
            'icp_number'     => $cfg['icp_number']     ?? '',
            'icp_link'       => $cfg['icp_link']       ?? 'https://beian.miit.gov.cn/',
            'police_number'  => $cfg['police_number']  ?? '',
            'police_link'    => $cfg['police_link']    ?? '',
            'copyright_text' => $cfg['copyright_text'] ?? '',
            'custom_footer'  => $cfg['custom_footer']  ?? ''
        ];
        json_exit(['ok' => true, 'data' => $out]);
        break;

    default:
        json_exit(['ok' => false, 'msg' => '未知操作: ' . $action]);
}
