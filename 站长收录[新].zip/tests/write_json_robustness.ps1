# writeJson 鲁棒性测试（纯PowerShell .NET API，避免Add-Type语法冲突）
$ErrorActionPreference = 'Stop'
$testRoot = Join-Path $env:TEMP ("hh_write_robust_" + [guid]::NewGuid().ToString("N").Substring(0,8))
New-Item -ItemType Directory -Path $testRoot | Out-Null
Write-Host "=== Test Root: $testRoot ===" -ForegroundColor Cyan

$script:pass=0; $script:fail=0
function Test($name, $cond, $d="") {
    if($cond){ $script:pass++; $c='Green'; $t='PASS' } else { $script:fail++; $c='Red'; $t='FAIL' }
    Write-Host "  [$t] $name" -ForegroundColor $c
    if(!$cond -and $d){ Write-Host "      -> $d" -ForegroundColor DarkYellow }
}

$UTF8NOBOM = New-Object System.Text.UTF8Encoding $false
function ReadAll($p){ return [System.IO.File]::ReadAllText($p, $UTF8NOBOM) }
function WriteAll($p, $s){ [System.IO.File]::WriteAllText($p, $s, $UTF8NOBOM) }

# ===========================================================
# OldWriter: 等价PHP file_put_contents($file, $json, LOCK_EX)
#   → FileMode.Create → 先截断后写，若被拒/只读，原内容会被清空
# ===========================================================
function OldWrite($file, $json) {
    try {
        $fs = New-Object System.IO.FileStream($file, [System.IO.FileMode]::Create,
            [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
        try {
            $bytes = $UTF8NOBOM.GetBytes($json)
            $fs.Write($bytes, 0, $bytes.Length)
            $fs.Flush($true)
            return $true
        } finally { $fs.Dispose() }
    } catch {
        return $false
    }
}

# ===========================================================
# NewWriter: 临时文件 + 原子替换（rename/replace）+ 只读清理 + 自动建目录
# ===========================================================
function NewWrite($file, $json) {
    try {
        $dir = [System.IO.Path]::GetDirectoryName($file)
        if(-not [System.IO.Directory]::Exists($dir)) {
            [System.IO.Directory]::CreateDirectory($dir) | Out-Null
        }
        if([System.IO.File]::Exists($file)) {
            $fi = New-Object System.IO.FileInfo($file)
            if(($fi.Attributes -band [System.IO.FileAttributes]::ReadOnly) -ne 0) {
                $fi.Attributes = $fi.Attributes -band (-bnot [System.IO.FileAttributes]::ReadOnly)
            }
        }
        $tmp = $file + ".tmp." + [guid]::NewGuid().ToString("N") + ".part"
        # CreateNew 保证同目录不会和其他并发线程同tmp名冲突（GUID）
        $fs = New-Object System.IO.FileStream($tmp, [System.IO.FileMode]::CreateNew,
            [System.IO.FileAccess]::Write, [System.IO.FileShare]::None,
            4096, [System.IO.FileOptions]::WriteThrough)
        try {
            $bytes = $UTF8NOBOM.GetBytes($json)
            $fs.Write($bytes, 0, $bytes.Length)
            $fs.Flush($true)
        } finally { $fs.Dispose() }
        # 原子替换
        if([System.IO.File]::Exists($file)) {
            [System.IO.File]::Replace($tmp, $file, $null)
        } else {
            [System.IO.File]::Move($tmp, $file)
        }
        return $true
    } catch {
        # 清理遗留tmp
        if($tmp -and [System.IO.File]::Exists($tmp)) {
            try { [System.IO.File]::Delete($tmp) } catch {}
        }
        return $false
    }
}

function IsValidJson($p) {
    try {
        $content = ReadAll $p
        if([string]::IsNullOrEmpty($content)) { return $false }
        Add-Type -AssemblyName System.Web.Extensions -ErrorAction SilentlyContinue
        $jss = New-Object System.Web.Script.Serialization.JavaScriptSerializer
        $jss.MaxJsonLength = [int]::MaxValue
        $null = $jss.DeserializeObject($content)
        return $true
    } catch {
        # 回退到PowerShell 5内置ConvertFrom-Json
        try {
            $null = Get-Content $p -Raw -Encoding UTF8 | ConvertFrom-Json
            return $true
        } catch { return $false }
    }
}

# Worker 子进程脚本（并发测试用）— 写到临时文件再用Start-Job -FilePath调用
function StartWorkers($path, $kind) {
    WriteAll $path '[]'
    $jobFiles = @()
    1..8 | ForEach-Object {
        $wid = $_
        $workerRoot = Join-Path $testRoot "worker_$kind`_$wid"
        New-Item -ItemType Directory -Force -Path $workerRoot | Out-Null
        $bodyOld = @'
$p = $args[0]; $wid = [int]$args[1]
$rnd = New-Object Random $wid
$utf8 = New-Object System.Text.UTF8Encoding $false
function OldWrite($file, $json) {
    try {
        $fs = New-Object System.IO.FileStream($file, [System.IO.FileMode]::Create,
            [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
        try { $b = $utf8.GetBytes($json); $fs.Write($b,0,$b.Length); $fs.Flush($true); return $true }
        finally { $fs.Dispose() }
    } catch { return $false }
}
for($i=0; $i -lt 20; $i++){
    $ch = [char](97 + ($wid % 26))
    $payload = [string]([char[]]([int]$ch)*300 -join '')
    $ticks = [DateTime]::UtcNow.Ticks
    $json = '[{"worker":' + $wid + ',"i":' + $i + ',"ts":' + $ticks + ',"payload":"' + $payload + '"}]'
    OldWrite $p $json | Out-Null
    Start-Sleep -Milliseconds ($rnd.Next(5,25))
}
'@
        $bodyNew = @'
$p = $args[0]; $wid = [int]$args[1]
$rnd = New-Object Random $wid
$utf8 = New-Object System.Text.UTF8Encoding $false
function NewWrite($file, $json) {
    try {
        $dir = [System.IO.Path]::GetDirectoryName($file)
        if(-not [System.IO.Directory]::Exists($dir)){ [void][System.IO.Directory]::CreateDirectory($dir) }
        if([System.IO.File]::Exists($file)){
            $fi = New-Object System.IO.FileInfo($file)
            if(($fi.Attributes -band [System.IO.FileAttributes]::ReadOnly) -ne 0){
                $fi.Attributes = $fi.Attributes -band (-bnot [System.IO.FileAttributes]::ReadOnly)
            }
        }
        $tmp = $file + ".tmp." + [guid]::NewGuid().ToString("N") + ".part"
        $fs = New-Object System.IO.FileStream($tmp, [System.IO.FileMode]::CreateNew,
            [System.IO.FileAccess]::Write, [System.IO.FileShare]::None, 4096, [System.IO.FileOptions]::WriteThrough)
        try { $b = $utf8.GetBytes($json); $fs.Write($b,0,$b.Length); $fs.Flush($true) }
        finally { $fs.Dispose() }
        if([System.IO.File]::Exists($file)){ [System.IO.File]::Replace($tmp, $file, $null) }
        else { [System.IO.File]::Move($tmp, $file) }
        return $true
    } catch { return $false }
}
for($i=0; $i -lt 20; $i++){
    $ch = [char](97 + ($wid % 26))
    $payload = [string]([char[]]([int]$ch)*300 -join '')
    $ticks = [DateTime]::UtcNow.Ticks
    $json = '[{"worker":' + $wid + ',"i":' + $i + ',"ts":' + $ticks + ',"payload":"' + $payload + '"}]'
    NewWrite $p $json | Out-Null
    Start-Sleep -Milliseconds ($rnd.Next(5,25))
}
'@
        $wf = Join-Path $workerRoot "run.ps1"
        if($kind -eq 'old') { Set-Content -Path $wf -Value $bodyOld -Encoding UTF8 }
        else { Set-Content -Path $wf -Value $bodyNew -Encoding UTF8 }
        $jobFiles += $wf
        $null = Start-Job -FilePath $wf -Name "w${kind}${wid}" -ArgumentList $path, $wid
    }
    $jobs = Get-Job | Where-Object { $_.Name -like "w${kind}*" }
    $null = $jobs | Wait-Job -Timeout 90
    try { $jobs | Remove-Job -Force -ErrorAction SilentlyContinue } catch {}
}

# ================= RED = OldWriter =================
Write-Host "`n[OLD - RED] 当前实现 (file_put_contents + LOCK_EX)"

$f1 = Join-Path $testRoot "o1.json"
Test "T1 正常写入成功" (OldWrite $f1 '[{"a":1}]')
Test "T1 内容完整" ((ReadAll $f1) -eq '[{"a":1}]')

$f2 = Join-Path $testRoot "o2.json"; $orig = '{"x":1}'
$null = OldWrite $f2 $orig
$fi2 = New-Object System.IO.FileInfo($f2)
$fi2.IsReadOnly = $true
$res = OldWrite $f2 '{"x":2}'
$actual = ReadAll $f2
$fi2.IsReadOnly = $false
Test "T2 只读属性: 写入返回false (预期)" ($res -eq $false)
Test "T2 只读属性: 原内容不能被截断/清空(缺陷!)" ($actual -eq $orig) `
  ("orig=[$orig] actual=[$actual] 长度=$($actual.Length)  注意OldWrite的FileMode.Create会先清空文件再抛权限异常，导致半写数据丢失")

$f3 = Join-Path $testRoot "o3.json"
StartWorkers $f3 'old'
$c3 = ReadAll $f3
Test "T3 并发写入8x20次后JSON合法(OldWriter易半写)" (IsValidJson $f3) `
  ("长度=$($c3.Length)  前200B=" + $c3.Substring(0, [Math]::Min(200, $c3.Length)))

$f4 = Join-Path $testRoot "sub1\nested\o4.json"
Test "T4 父目录不存在:OldWriter写入失败 (预期RED)" ((OldWrite $f4 '[1,2,3]') -eq $false)

# ================= GREEN = NewWriter =================
Write-Host "`n[NEW - GREEN] 改进实现 (临时文件+原子替换+自动建目录+只读清理)"

$n1 = Join-Path $testRoot "n1.json"
Test "T1 正常写入成功" (NewWrite $n1 '[{"a":1}]')
Test "T1 内容完整" ((ReadAll $n1) -eq '[{"a":1}]')

$n2 = Join-Path $testRoot "n2.json"; $orig = '{"x":1}'
$null = NewWrite $n2 $orig
$fi = New-Object System.IO.FileInfo($n2)
$fi.IsReadOnly = $true
$res = NewWrite $n2 '{"x":2}'
$actual = ReadAll $n2
Test "T2 只读属性: 写入成功 (自动清ReadOnly)" ($res -eq $true)
Test "T2 只读属性: 内容正确更新" ($actual -eq '{"x":2}')
$fi.IsReadOnly = $false

$n3 = Join-Path $testRoot "n3.json"
StartWorkers $n3 'new'
$c3 = ReadAll $n3
Test "T3 并发写入8x20次后JSON合法(原子替换)" (IsValidJson $n3) `
  ("长度=$($c3.Length)  前200B=" + $c3.Substring(0, [Math]::Min(200, $c3.Length)))

$n4 = Join-Path $testRoot "sub2\nested-deep\n4.json"
Test "T4 父目录不存在: NewWriter自动建目录+写入成功" (NewWrite $n4 '[1,2,3]')
Test "T4 父目录不存在: 内容正确" ((Test-Path $n4) -and ((ReadAll $n4) -eq '[1,2,3]'))

# T5 大文件
$n5 = Join-Path $testRoot "n5.json"
$items = New-Object System.Collections.Generic.List[string]
1..500 | ForEach-Object { $items.Add('{"item":"' + $_ + '","p":"' + ('x'*200) + '"}') }
$big = "[" + ($items -join ",") + "]"
Test "T5 100KB+大文件写入成功" (NewWrite $n5 $big)
Test "T5 内容一致" ((ReadAll $n5) -ceq $big)
Test "T5 JSON合法" (IsValidJson $n5)

Write-Host "`n=== RESULT: PASS=$script:pass  FAIL=$script:fail ===" `
  -ForegroundColor $(if($script:fail -gt 0){'Red'}else{'Green'})
Remove-Item $testRoot -Recurse -Force -ErrorAction SilentlyContinue
if($script:fail -gt 0){ exit 1 } else { exit 0 }
