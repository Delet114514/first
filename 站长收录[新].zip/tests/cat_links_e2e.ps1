# E2E interface test for category-link management (double source)
param([int]$Port = 5175)
$ErrorActionPreference = 'Stop'
$Base  = "http://localhost:$Port/api.php"
$Token = '8c87e31b2ebd6e399a0319d2a1389ea6'
$Proj  = Split-Path $PSScriptRoot -Parent
$SiteDataFile = Join-Path $Proj 'data\site_data.json'
$SubmissionsFile = Join-Path $Proj 'data\submissions.json'
$origSiteData    = Get-Content -Raw -LiteralPath $SiteDataFile -Encoding UTF8
$origSubmissions = Get-Content -Raw -LiteralPath $SubmissionsFile -Encoding UTF8

function Post($action, $body) {
  if ($body -is [hashtable]) {
    if (-not $body.ContainsKey('admin_token')) { $body['admin_token'] = $Token }
    $bodyJson = ConvertTo-Json $body -Depth 10 -Compress
  } else {
    $bodyJson = [string]$body
  }
  try {
    return Invoke-RestMethod -Uri ($Base + '?action=' + $action) -Method POST -ContentType 'application/json; charset=utf-8' -Body $bodyJson -TimeoutSec 10
  } catch {
    $msg = $_.Exception.Message
    try {
      $stream = $_.Exception.Response.GetResponseStream()
      $reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::UTF8)
      Write-Host ("  [HTTP_BODY] " + $reader.ReadToEnd())
    } catch {}
    return @{ ok = $false; msg = ("HTTP_ERR: " + $msg) }
  }
}

function AE($expect, $actual, $name) {
  if ($expect -cne $actual -and [string]$expect -ne [string]$actual) {
    throw ("ASSERT FAIL [{0}] expect=<{1}> actual=<{2}>" -f $name, $expect, $actual)
  }
  Write-Host ("  OK  {0} = {1}" -f $name, $actual) -ForegroundColor Green
}
function AT($val, $name) {
  if (-not $val) { throw ("ASSERT FAIL [{0}] truthy expected, got=<{1}>" -f $name, ($val | Out-String).Trim()) }
  $valStr = [string]$val
  if ($valStr.Length -gt 60) { $valStr = $valStr.Substring(0,60) + '...' }
  Write-Host ("  OK  {0} truthy (<{1}>)" -f $name, $valStr) -ForegroundColor Green
}

try {
  Write-Host ""
  Write-Host "=== [0] admin_stats sanity ===" -ForegroundColor Cyan
  $r = Post 'admin_stats' @{}
  AT $r.ok "admin_stats.ok"
  Write-Host ("  users={0} pending={1} approved={2}" -f $r.data.users, $r.data.pending, $r.data.approved)

  Write-Host ""
  Write-Host "=== [1] Seed site_data.json directly (write categories) ===" -ForegroundColor Cyan
  $pay = @(); 1..8 | ForEach-Object { $pay += @{id=$_;name="Pay$_";desc="Pay$_ desc";link="#";sort=$_} }
  $server = @(); 1..10 | ForEach-Object { $server += @{id=$_;name="Server$_";desc="Server$_ desc";link="#";sort=$_} }
  $dist   = @(@{id=1;name="Dist1";desc="D1";link="#";sort=1},@{id=2;name="Dist2";desc="D2";link="#";sort=2})
  $nav    = @(@{id=1;name="Nav1";desc="N1";link="#";sort=1},@{id=2;name="Nav2";desc="N2";link="#";sort=2},@{id=3;name="Nav3";desc="N3";link="#";sort=3},@{id=4;name="Nav4";desc="N4";link="#";sort=4},@{id=5;name="Nav5";desc="N5";link="#";sort=5},@{id=6;name="Nav6";desc="N6";link="#";sort=6},@{id=7;name="Nav7";desc="N7";link="#";sort=7})
  $login  = @(@{id=1;name="Login1";desc="L1";link="#";sort=1},@{id=2;name="Login2";desc="L2";link="#";sort=2})
  $blog   = @(@{id=1;name="Blog1";desc="B1";link="#";sort=1},@{id=2;name="Blog2";desc="B2";link="#";sort=2},@{id=3;name="Blog3";desc="B3";link="#";sort=3},@{id=4;name="Blog4";desc="B4";link="#";sort=4},@{id=5;name="Blog5";desc="B5";link="#";sort=5},@{id=6;name="Blog6";desc="B6";link="#";sort=6})
  $card   = @(@{id=1;name="Card1";desc="C1";link="#";sort=1},@{id=2;name="Card2";desc="C2";link="#";sort=2},@{id=3;name="Card3";desc="C3";link="#";sort=3},@{id=4;name="Card4";desc="C4";link="#";sort=4},@{id=5;name="Card5";desc="C5";link="#";sort=5},@{id=6;name="Card6";desc="C6";link="#";sort=6})
  $tool   = @(@{id=1;name="Tool1";desc="T1";link="#";sort=1},@{id=2;name="Tool2";desc="T2";link="#";sort=2},@{id=3;name="Tool3";desc="T3";link="#";sort=3},@{id=4;name="Tool4";desc="T4";link="#";sort=4},@{id=5;name="Tool5";desc="T5";link="#";sort=5},@{id=6;name="Tool6";desc="T6";link="#";sort=6})
  $siteObj = @{
    settings   = @{username='admin';password='admin123';siteName='SITE';siteTitle='TITLE'}
    banner_ads = @(@{id=1;title='B';image='x.jpg';link='#';sort=1})
    grid_ads   = @(@{id=1;title='G';desc='g';image='g.jpg';link='#';sort=1})
    categories = @{pay=$pay;server=$server;dist=$dist;nav=$nav;login=$login;blog=$blog;card=$card;tool=$tool}
  }
  $siteJson = ConvertTo-Json $siteObj -Depth 10
  Set-Content -LiteralPath $SiteDataFile -Value $siteJson -NoNewline -Encoding UTF8
  # 再次调用 get_site_data（若实现） / admin_stats 确认 server 读取文件成功
  $check = Post 'admin_stats' @{}
  AT $check.ok "after seed, api still reachable"
  Write-Host "  site_data.json written with $(($siteJson -join '').Length) chars" -ForegroundColor DarkGray

  Write-Host ""
  Write-Host "=== [2] get_category_links(server): custom=10 + 1 approved submission = 11 ===" -ForegroundColor Cyan
  $r = Post 'get_category_links' @{ category = 'server' }
  AT $r.ok 'server list ok'
  $list = $r.data.list
  $cust = @($list | Where-Object { $_.source -eq 'custom' })
  $subs = @($list | Where-Object { $_.source -eq 'submission' })
  AE 11 $list.Count 'server list total (10 custom + 1 approved)'
  AE 10 $cust.Count 'server custom count = 10'
  AE 1  $subs.Count 'server approved-submission count = 1'
  # submissions.json contains id 20260830000000002 approved in category server
  AE '20260830000000002' $subs[0].submission_id 'server submission id'
  AT ($subs[0].source -eq 'submission') 'server submission source == submission'
  AT ((-not $subs[0].hidden) -or ($subs[0].hidden -eq $false)) 'server submission hidden flag off'

  Write-Host ""
  Write-Host "=== [3] get_category_links(blog): 6 custom + 1 approved alice = 7 ===" -ForegroundColor Cyan
  $r = Post 'get_category_links' @{ category = 'blog' }
  $list = $r.data.list
  AE 7 $list.Count 'blog total (6+1)'
  $alice = @($list | Where-Object { $_.source -eq 'submission' -and [string]$_.submission_id -eq '20260830004126787' })
  AE 1 $alice.Count 'alice approved present in blog'
  $alice = $alice[0]

  Write-Host ""
  Write-Host "=== [4] approved_sites (front-end feed): both server + blog approved visible ===" -ForegroundColor Cyan
  $r = Post 'approved_sites' @{}
  $list = @($r.data)
  $srv  = @($list | Where-Object { [string]$_.category -eq 'server' })
  $blg  = @($list | Where-Object { [string]$_.name -like '*Alice*' -or [string]$_.name -like '*alice*' -or [string]$_.category -eq 'blog' })
  Write-Host ("  approved_sites count = {0}" -f $list.Count)
  AT ($list.Count -ge 3) "approved_sites >= 3 (at least server + blog + nav approved)"
  AT ($srv.Count -ge 1) "approved_sites contains server approved"

  Write-Host ""
  Write-Host "=== [5] admin_manage_link op=delete (soft-hide) server submission ===" -ForegroundColor Cyan
  $r = Post 'admin_manage_link' @{ op='delete'; source='submission'; category='server'; submission_id='20260830000000002' }
  AT $r.ok ('submission soft-hide -> ' + ($r.msg -join ''))

  Write-Host ""
  Write-Host "=== [6] After soft-hide: cat-manage shows hidden=true; front-end approved_sites hides it ===" -ForegroundColor Cyan
  $r = Post 'get_category_links' @{ category = 'server' }
  $hit = @($r.data.list | Where-Object { [string]$_.submission_id -eq '20260830000000002' })
  AE 1 $hit.Count 'server: hidden submission still visible in cat-manage'
  AT ($hit[0].hidden -eq $true -or [string]$hit[0].hidden -eq 'True') 'server submission hidden flag set TRUE'
  $fr = Post 'approved_sites' @{}
  $gone = @(@($fr.data) | Where-Object { [string]$_.category -eq 'server' })
  AE 0 $gone.Count 'approved_sites: server approved NO LONGER visible (hidden filtered out)'

  Write-Host ""
  Write-Host "=== [7] op=unhide -> server submission back to front-end ===" -ForegroundColor Cyan
  $r = Post 'admin_manage_link' @{ op='unhide'; source='submission'; category='server'; submission_id='20260830000000002' }
  AT $r.ok ('unhide -> ' + ($r.msg -join ''))
  $fr = Post 'approved_sites' @{}
  $now = @(@($fr.data) | Where-Object { [string]$_.category -eq 'server' })
  AE 1 $now.Count 'approved_sites: server approved visible again'

  Write-Host ""
  Write-Host "=== [8] op=create custom link in category pay ===" -ForegroundColor Cyan
  $r = Post 'admin_manage_link' @{ op='create'; source='custom'; category='pay'; name='E2E-Pay-NEW'; desc='Created via API'; link='https://e2e-pay.example.com'; sort=99 }
  AT $r.ok ('custom create -> ' + ($r.msg -join ''))
  $r = Post 'get_category_links' @{ category = 'pay' }
  $hit = @($r.data.list | Where-Object { $_.source -eq 'custom' -and [string]$_.name -eq 'E2E-Pay-NEW' })
  AE 1 $hit.Count 'pay: new custom link present'
  AE 99 ([int]$hit[0].sort) 'pay: new custom sort = 99'
  $newCustomId = [int]$hit[0].id
  Write-Host ("  assigned new custom id = {0}" -f $newCustomId)

  Write-Host ""
  Write-Host "=== [9] op=update custom link (rename+sort change) ===" -ForegroundColor Cyan
  $r = Post 'admin_manage_link' @{ op='update'; source='custom'; category='pay'; id=$newCustomId; name='E2E-Pay-RENAMED'; desc='UPDATED-DESC'; link='https://e2e-pay-v2.example.com'; sort=88 }
  AT $r.ok ('custom update -> ' + ($r.msg -join ''))
  $r = Post 'get_category_links' @{ category = 'pay' }
  $after = @($r.data.list | Where-Object { $_.source -eq 'custom' -and [int]$_.id -eq $newCustomId })
  AE 1 $after.Count 'custom after update still 1 hit'
  AE 'E2E-Pay-RENAMED' $after[0].name  'custom name updated'
  AE 'UPDATED-DESC'   $after[0].desc  'custom desc updated'
  AE 'https://e2e-pay-v2.example.com' $after[0].link 'custom link updated'
  AE 88 ([int]$after[0].sort) 'custom sort 99 -> 88'

  Write-Host ""
  Write-Host "=== [10] op=delete custom link ===" -ForegroundColor Cyan
  $r = Post 'admin_manage_link' @{ op='delete'; source='custom'; category='pay'; id=$newCustomId }
  AT $r.ok ('custom delete -> ' + ($r.msg -join ''))
  $r = Post 'get_category_links' @{ category = 'pay' }
  $gone = @($r.data.list | Where-Object { $_.source -eq 'custom' -and [int]$_.id -eq $newCustomId })
  AE 0 $gone.Count 'custom link physically removed'

  Write-Host ""
  Write-Host "=== [11] op=update submission + category_new=dist (migrate alice blog->dist) ===" -ForegroundColor Cyan
  $r = Post 'admin_manage_link' @{
    op='update'
    source='submission'
    category='blog'
    submission_id='20260830004126787'
    name='Alice-Migrated'
    desc='Migrated from blog to dist'
    link='https://alice-moved.example.com'
    category_new='dist'
  }
  AT $r.ok ('submission update + migrate -> ' + ($r.msg -join ''))
  $blog = (Post 'get_category_links' @{ category = 'blog' }).data.list
  $dist = (Post 'get_category_links' @{ category = 'dist' }).data.list
  $inBlog = @($blog | Where-Object { [string]$_.submission_id -eq '20260830004126787' })
  $inDist = @($dist | Where-Object { [string]$_.submission_id -eq '20260830004126787' })
  AE 0 $inBlog.Count 'alice no longer in blog'
  AE 1 $inDist.Count 'alice now in dist'
  AE 'Alice-Migrated' $inDist[0].name 'alice name updated in dist'
  AE 'https://alice-moved.example.com' $inDist[0].link 'alice link updated in dist'

  Write-Host ""
  Write-Host "=== [12] approved_sites: alice visible in NEW category dist ===" -ForegroundColor Cyan
  $fr = Post 'approved_sites' @{}
  $front = @($fr.data)
  $inFront = @($front | Where-Object { [string]$_.name -eq 'Alice-Migrated' })
  AE 1 $inFront.Count 'alice still in approved_sites feed'
  AE 'dist' $inFront[0].category 'alice category in feed = dist (migrated)'

  Write-Host ""
  Write-Host "=== [13] op=purge -> alice record physically deleted from submissions ===" -ForegroundColor Cyan
  $r = Post 'admin_manage_link' @{ op='purge'; source='submission'; category='dist'; submission_id='20260830004126787' }
  AT $r.ok ('purge -> ' + ($r.msg -join ''))
  $dist = (Post 'get_category_links' @{ category = 'dist' }).data.list
  $purged = @($dist | Where-Object { [string]$_.submission_id -eq '20260830004126787' })
  AE 0 $purged.Count 'alice GONE from category dist (purged)'
  $fr = Post 'approved_sites' @{}
  $fgone = @(@($fr.data) | Where-Object { [string]$_.name -eq 'Alice-Migrated' })
  AE 0 $fgone.Count 'alice GONE from approved_sites feed too'

  Write-Host ""
  Write-Host "=== [14] bad admin_token -> permission denied ===" -ForegroundColor Cyan
  $r = Post 'admin_manage_link' @{ admin_token='wrong'; op='create'; source='custom'; category='pay'; name='X'; link='http://x'; sort=1 }
  if ($r.ok) { throw 'BAD TOKEN accepted! Security issue.' }
  Write-Host ("  OK  bad token rejected -> {0}" -f ($r.msg -join '')) -ForegroundColor Green

  Write-Host ""
  Write-Host "#################################################################" -ForegroundColor Green
  Write-Host "#            ALL E2E CATEGORY-LINK TESTS PASSED                 #" -ForegroundColor Green
  Write-Host "#################################################################" -ForegroundColor Green
} catch {
  Write-Host ""
  Write-Host ("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!") -ForegroundColor Red
  Write-Host ("!! TEST FAILED: {0}" -f $_.Exception.Message) -ForegroundColor Red
  Write-Host ("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!") -ForegroundColor Red
  Write-Host $_.ScriptStackTrace -ForegroundColor DarkGray
  exit 1
} finally {
  try {
    Set-Content -LiteralPath $SiteDataFile -Value $origSiteData -NoNewline -Encoding UTF8
  } catch { Write-Host ("WARN: restore site_data failed: " + $_.Exception.Message) -ForegroundColor Yellow }
  try {
    Set-Content -LiteralPath $SubmissionsFile -Value $origSubmissions -NoNewline -Encoding UTF8
  } catch { Write-Host ("WARN: restore submissions failed: " + $_.Exception.Message) -ForegroundColor Yellow }
  Write-Host "restored site_data.json + submissions.json to pre-test snapshots."
}
