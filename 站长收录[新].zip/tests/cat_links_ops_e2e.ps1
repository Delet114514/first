$BASE = 'http://localhost:5175/api.php'
$TKN  = '8c87e31b2ebd6e399a0319d2a1389ea6'

function CallApi($action, $payload) {
  $body = $payload | ConvertTo-Json -Depth 10 -Compress
  $r = Invoke-WebRequest -Uri "$BASE`?action=$action" -Method POST -ContentType 'application/json' -Body $body -UseBasicParsing
  return ($r.Content | ConvertFrom-Json)
}

Write-Host '=== PREP: restore submission link via re-seeding (to ensure not already purged) ==='
# Add mock approved submission via direct api call using test endpoint? Simpler: rely on existing one.
# We start by listing to find the submission.
$list = CallApi 'get_category_links' @{admin_token=$TKN; category='server'}
$sub = $list.data.list | Where-Object { $_.source -eq 'submission' } | Select-Object -First 1
if (-not $sub) { Write-Host 'ERROR: No submission link found. SKIPPING A/B/C/G'; $Askip=$true } else { $Askip=$false; Write-Host ('target: name=' + $sub.name + ' submission_id=' + $sub.submission_id) }

Write-Host '=== A. Hide submission (op=delete does soft delete: hidden=true) ==='
if (-not $Askip) {
  $r1 = CallApi 'admin_manage_link' @{admin_token=$TKN; op='delete'; category='server'; source='submission'; submission_id=$sub.submission_id}
  Write-Host ('hide result: ok=' + $r1.ok + ' msg=' + $r1.msg)
  $front = CallApi 'approved_sites' @{category='server'}
  $frontUrls = @()
  foreach ($s in $front.data) { $frontUrls += $s.link }
  Write-Host ('Frontend approved count after hide: ' + $front.data.Count + ' contains target? ' + ($frontUrls -contains $sub.link))
}

Write-Host '=== B. get_category_links hidden count should be 1 ==='
$list2 = CallApi 'get_category_links' @{admin_token=$TKN; category='server'}
$total=0; $cu=0; $su=0; $hd=0
foreach ($i in $list2.data.list) {
  $total++
  if ($i.source -eq 'custom') { $cu++ } else { $su++ }
  if ($i.hidden) { $hd++ }
}
Write-Host "total=$total custom=$cu sub=$su hidden=$hd"

Write-Host '=== C. Unhide submission ==='
if (-not $Askip) {
  $r2 = CallApi 'admin_manage_link' @{admin_token=$TKN; op='unhide'; category='server'; source='submission'; submission_id=$sub.submission_id}
  Write-Host ('unhide result: ok=' + $r2.ok + ' msg=' + $r2.msg)
  $front2 = CallApi 'approved_sites' @{category='server'}
  $frontUrls2 = @()
  foreach ($s in $front2.data) { $frontUrls2 += $s.link }
  Write-Host ('Frontend approved count after unhide: ' + $front2.data.Count + ' contains target? ' + ($frontUrls2 -contains $sub.link))
}

Write-Host '=== D. Edit custom link Server1 -> Server1-EDITED ==='
$list3 = CallApi 'get_category_links' @{admin_token=$TKN; category='server'}
$c1 = $list3.data.list | Where-Object { $_.source -eq 'custom' -and [string]$_.id -eq '1' } | Select-Object -First 1
Write-Host ('before edit: name=' + $c1.name)
$r3 = CallApi 'admin_manage_link' @{admin_token=$TKN; op='update'; category='server'; source='custom'; id='1'; name='Server1-EDITED'; desc='edited desc'; link='http://example.com'; sort=1}
Write-Host ('edit result: ok=' + $r3.ok + ' msg=' + $r3.msg)
$list4 = CallApi 'get_category_links' @{admin_token=$TKN; category='server'}
$c2 = $list4.data.list | Where-Object { $_.source -eq 'custom' -and [string]$_.id -eq '1' } | Select-Object -First 1
Write-Host ('after edit: name=' + $c2.name + ' desc=' + $c2.desc + ' link=' + $c2.link)

Write-Host '=== E. Add new custom link NewCustom1 ==='
$r4 = CallApi 'admin_manage_link' @{admin_token=$TKN; op='create'; category='server'; source='custom'; name='NewCustom1'; desc='new desc'; link='http://new.example.com'; sort=5}
Write-Host ('create result: ok=' + $r4.ok + ' newId=' + $r4.data.id + ' msg=' + $r4.msg)
$list5 = CallApi 'get_category_links' @{admin_token=$TKN; category='server'}
$foundNew = $list5.data.list | Where-Object { $_.name -eq 'NewCustom1' } | Select-Object -First 1
Write-Host ('found new: ' + ($foundNew -ne $null) + ' sort=' + $foundNew.sort)

Write-Host '=== F. Delete new custom link ==='
$r5 = CallApi 'admin_manage_link' @{admin_token=$TKN; op='delete'; category='server'; source='custom'; id=$r4.data.id}
Write-Host ('delete result: ok=' + $r5.ok + ' msg=' + $r5.msg)

Write-Host '=== G. Purge (permanent delete) submission link ==='
if (-not $Askip) {
  $r6 = CallApi 'admin_manage_link' @{admin_token=$TKN; op='purge'; category='server'; source='submission'; submission_id=$sub.submission_id}
  Write-Host ('purge result: ok=' + $r6.ok + ' msg=' + $r6.msg)
  $list6 = CallApi 'get_category_links' @{admin_token=$TKN; category='server'}
  $still = $list6.data.list | Where-Object { $_.source -eq 'submission' -and $_.submission_id -eq $sub.submission_id } | Select-Object -First 1
  Write-Host ('submission still in category list: ' + ($still -ne $null))
  $front3 = CallApi 'approved_sites' @{category='server'}
  $still2 = $front3.data | Where-Object { $_.link -eq $sub.link } | Select-Object -First 1
  Write-Host ('submission still in frontend: ' + ($still2 -ne $null))
}
