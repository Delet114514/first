$BASE = 'http://localhost:5176/api.php'
$TKN  = '8c87e31b2ebd6e399a0319d2a1389ea6'

function CallApi($action, $payload) {
  $body = $payload | ConvertTo-Json -Depth 10 -Compress
  try {
    $r = Invoke-WebRequest -Uri "$BASE`?action=$action" -Method POST -ContentType 'application/json' -Body $body -UseBasicParsing
    return ($r.Content | ConvertFrom-Json)
  } catch {
    $resp = $_.Exception.Response
    if ($resp) {
      $reader = New-Object System.IO.StreamReader($resp.GetResponseStream())
      $body = $reader.ReadToEnd()
      Write-Host ("HTTP_ERR: status=" + $resp.StatusCode + " body=" + $body)
    } else {
      Write-Host ("HTTP_ERR: " + $_.Exception.Message)
    }
    return [pscustomobject]@{ok=$false; msg=('HTTP_ERR ' + $_.Exception.Message)}
  }
}

Write-Host '=== 1. Category links list after seed new approved server submission ==='
$list = CallApi 'get_category_links' @{admin_token=$TKN; category='server'}
$total=0; $cu=0; $su=0; $hd=0
foreach ($i in $list.data.list) {
  $total++
  if ($i.source -eq 'custom') { $cu++ } else { $su++ }
  if ($i.hidden) { $hd++ }
}
Write-Host "total=$total custom=$cu sub=$su hidden=$hd"
# Expect custom=11 (previous E created+failed delete) sub=1 hidden=0 total=12

Write-Host '=== Extra: Clean previous leftover NewCustom1 (custom link named NewCustom1 or CustomNEW) ==='
foreach ($i in $list.data.list) {
  if ($i.source -eq 'custom' -and ($i.name -eq 'NewCustom1' -or $i.name -eq 'CustomNEW')) {
    Write-Host ('Cleaning leftover id=' + $i.id + ' name=' + $i.name)
    $r = CallApi 'admin_manage_link' @{admin_token=$TKN; op='delete'; category='server'; source='custom'; id=([string]$i.id)}
    Write-Host ('  clean result: ok=' + $r.ok + ' msg=' + $r.msg)
  }
}

Write-Host '=== 2. Target submission (source=submission, category=server) ==='
$list2 = CallApi 'get_category_links' @{admin_token=$TKN; category='server'}
$sub = $list2.data.list | Where-Object { $_.source -eq 'submission' -and $_.category -eq 'server' } | Select-Object -First 1
Write-Host ('target: name=' + $sub.name + ' submission_id=' + $sub.submission_id + ' hidden=' + $sub.hidden)

Write-Host '=== A. Hide submission (op=delete => hidden=true) ==='
$ra = CallApi 'admin_manage_link' @{admin_token=$TKN; op='delete'; category='server'; source='submission'; submission_id=$sub.submission_id}
Write-Host ('A hide: ok=' + $ra.ok + ' msg=' + $ra.msg)
$frontA = CallApi 'approved_sites' @{category='server'}
$hasTargetA = $false
foreach ($s in $frontA.data) { if ($s.link -eq $sub.link) { $hasTargetA = $true } }
Write-Host ('A frontend contains target? ' + $hasTargetA + ' EXPECTED: False')

Write-Host '=== B. hidden=1 in list ==='
$listB = CallApi 'get_category_links' @{admin_token=$TKN; category='server'}
$hB = 0
foreach ($i in $listB.data.list) { if ($i.hidden -eq $true -or $i.hidden -eq 'True' -or $i.hidden -eq 1) { $hB++ } }
Write-Host ('B hidden count=' + $hB + ' EXPECTED: 1')

Write-Host '=== C. Unhide submission ==='
$rc = CallApi 'admin_manage_link' @{admin_token=$TKN; op='unhide'; category='server'; source='submission'; submission_id=$sub.submission_id}
Write-Host ('C unhide: ok=' + $rc.ok + ' msg=' + $rc.msg)
$frontC = CallApi 'approved_sites' @{category='server'}
$hasTargetC = $false
foreach ($s in $frontC.data) { if ($s.link -eq $sub.link) { $hasTargetC = $true } }
Write-Host ('C frontend contains target? ' + $hasTargetC + ' EXPECTED: True')

Write-Host '=== D. Edit custom id=1: Server1 -> CUSTOM-EDITED ==='
$rd = CallApi 'admin_manage_link' @{admin_token=$TKN; op='update'; category='server'; source='custom'; id='1'; name='CUSTOM-EDITED'; desc='edited by E2E'; link='http://edited.example.com'; sort=1}
Write-Host ('D edit: ok=' + $rd.ok + ' msg=' + $rd.msg)
$listD = CallApi 'get_category_links' @{admin_token=$TKN; category='server'}
$cD = $listD.data.list | Where-Object { $_.source -eq 'custom' -and [string]$_.id -eq '1' } | Select-Object -First 1
Write-Host ('D after: name=' + $cD.name + ' desc=' + $cD.desc + ' link=' + $cD.link + ' EXPECTED name=CUSTOM-EDITED')

Write-Host '=== E. Create new custom link EXPECT id returned + inserted ==='
$re = CallApi 'admin_manage_link' @{admin_token=$TKN; op='create'; category='server'; source='custom'; name='CREATED-E2E'; desc='created by E2E'; link='http://created.example.com'; sort=7}
Write-Host ('E create: ok=' + $re.ok + ' msg=' + $re.msg + ' id=' + $re.data.id)
if (-not $re.ok -or [string]$re.data.id -eq '') { Write-Host 'E FAIL (no id returned or ok=false)' }
$listE = CallApi 'get_category_links' @{admin_token=$TKN; category='server'}
$foundE = $false
foreach ($i in $listE.data.list) { if ($i.name -eq 'CREATED-E2E') { $foundE = $true } }
Write-Host ('E found CREATED-E2E in list? ' + $foundE + ' EXPECTED: True')

Write-Host '=== F. Delete new custom link using returned id EXPECT ok=true ==='
if ($re.ok -and [string]$re.data.id -ne '') {
  $rf = CallApi 'admin_manage_link' @{admin_token=$TKN; op='delete'; category='server'; source='custom'; id=$re.data.id}
  Write-Host ('F delete: ok=' + $rf.ok + ' msg=' + $rf.msg)
  $listF = CallApi 'get_category_links' @{admin_token=$TKN; category='server'}
  $stillF = $false
  foreach ($i in $listF.data.list) { if ($i.name -eq 'CREATED-E2E') { $stillF = $true } }
  Write-Host ('F CREATED-E2E still in list? ' + $stillF + ' EXPECTED: False')
} else {
  Write-Host 'F SKIPPED (E failed)'
}

Write-Host '=== G. Purge submission (permanent delete) EXPECT gone from UI and frontend ==='
$rg = CallApi 'admin_manage_link' @{admin_token=$TKN; op='purge'; category='server'; source='submission'; submission_id=$sub.submission_id}
Write-Host ('G purge: ok=' + $rg.ok + ' msg=' + $rg.msg)
$listG = CallApi 'get_category_links' @{admin_token=$TKN; category='server'}
$stillG1 = $false
foreach ($i in $listG.data.list) { if ($i.submission_id -eq $sub.submission_id) { $stillG1 = $true } }
Write-Host ('G submission still in category list? ' + $stillG1 + ' EXPECTED: False')
$frontG = CallApi 'approved_sites' @{category='server'}
$stillG2 = $false
foreach ($s in $frontG.data) { if ($s.link -eq $sub.link) { $stillG2 = $true } }
Write-Host ('G submission still in frontend approved list? ' + $stillG2 + ' EXPECTED: False')

Write-Host ''
Write-Host '=== ALL DONE. A~G should be all True and EXPECTED matched.'
