$Proj = 'd:\桌面\网站项目\收录'
$File = Join-Path $Proj 'data\site_data.json'
$pay = @(); 1..8 | ForEach-Object { $pay += @{id=$_;name="Pay$_";desc="Pay$_ desc";link="#";sort=$_} }
$server = @(); 1..10 | ForEach-Object { $server += @{id=$_;name="Server$_";desc="Server$_ desc";link="#";sort=$_} }
$dist   = @(@{id=1;name='Dist1';desc='D1';link='#';sort=1},@{id=2;name='Dist2';desc='D2';link='#';sort=2})
$nav    = @(@{id=1;name='Nav1';desc='N1';link='#';sort=1},@{id=2;name='Nav2';desc='N2';link='#';sort=2},@{id=3;name='Nav3';desc='N3';link='#';sort=3},@{id=4;name='Nav4';desc='N4';link='#';sort=4},@{id=5;name='Nav5';desc='N5';link='#';sort=5},@{id=6;name='Nav6';desc='N6';link='#';sort=6},@{id=7;name='Nav7';desc='N7';link='#';sort=7})
$login  = @(@{id=1;name='Login1';desc='L1';link='#';sort=1},@{id=2;name='Login2';desc='L2';link='#';sort=2})
$blog   = @(@{id=1;name='Blog1';desc='B1';link='#';sort=1},@{id=2;name='Blog2';desc='B2';link='#';sort=2},@{id=3;name='Blog3';desc='B3';link='#';sort=3},@{id=4;name='Blog4';desc='B4';link='#';sort=4},@{id=5;name='Blog5';desc='B5';link='#';sort=5},@{id=6;name='Blog6';desc='B6';link='#';sort=6})
$card   = @(@{id=1;name='Card1';desc='C1';link='#';sort=1},@{id=2;name='Card2';desc='C2';link='#';sort=2},@{id=3;name='Card3';desc='C3';link='#';sort=3},@{id=4;name='Card4';desc='C4';link='#';sort=4},@{id=5;name='Card5';desc='C5';link='#';sort=5},@{id=6;name='Card6';desc='C6';link='#';sort=6})
$tool   = @(@{id=1;name='Tool1';desc='T1';link='#';sort=1},@{id=2;name='Tool2';desc='T2';link='#';sort=2},@{id=3;name='Tool3';desc='T3';link='#';sort=3},@{id=4;name='Tool4';desc='T4';link='#';sort=4},@{id=5;name='Tool5';desc='T5';link='#';sort=5},@{id=6;name='Tool6';desc='T6';link='#';sort=6})
$obj = @{
  settings   = @{username='admin';password='admin123';siteName='HH Cloud';siteTitle='HH Cloud Nav - Premium Directory'}
  banner_ads = @(@{id=1;title='Banner1';image='b1.jpg';link='#';sort=1})
  grid_ads   = @(@{id=1;title='Grid1';desc='g';image='g1.jpg';link='#';sort=1})
  categories = @{pay=$pay;server=$server;dist=$dist;nav=$nav;login=$login;blog=$blog;card=$card;tool=$tool}
}
$json = ConvertTo-Json $obj -Depth 10
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllText($File, $json, $utf8NoBom)
Write-Host ("Written site_data.json: " + (Get-Item -LiteralPath $File).Length + " bytes")
