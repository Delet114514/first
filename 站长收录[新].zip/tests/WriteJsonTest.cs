using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;

/* RED 阶段：验证当前writeJson实现(等价file_put_contents+LOCK_EX)的缺陷
   GREEN阶段：验证NewWriter(临时文件+原子rename+只读属性清理)的改进
*/

public static class Logger {
    public static int Pass, Fail;
    public static void Check(string name, bool cond, string detail="") {
        if(cond) { Pass++; Console.WriteLine("  [PASS] {0}", name); }
        else { Fail++; Console.WriteLine("  [FAIL] {0}", name); if(detail!="") Console.WriteLine("      -> {0}", detail); }
    }
}

// 等价PHP当前writeJson：file_put_contents($file, $json, LOCK_EX)
public static class OldWriter {
    public static bool Write(string file, string json, out string err) {
        err = null;
        try {
            using(var fs = new FileStream(file, FileMode.Create, FileAccess.Write, FileShare.None)) {
                var b = Encoding.UTF8.GetBytes(json);
                fs.Write(b, 0, b.Length);
                fs.Flush(true);
            }
            return true;
        } catch(Exception e) {
            err = e.GetType().Name + ": " + e.Message;
            return false;
        }
    }
}

// 改进版 writeJson: 临时文件 + 原子替换 + 只读清理 + 目录自动创建 + 重试
public static class NewWriter {
    public static bool Write(string file, string json, out string err) {
        err = null;
        try {
            var dir = Path.GetDirectoryName(file);
            if(!Directory.Exists(dir)) {
                Directory.CreateDirectory(dir);
            }
            // 清理可能的只读属性
            if(File.Exists(file)) {
                var fi = new FileInfo(file);
                if((fi.Attributes & FileAttributes.ReadOnly) != 0) {
                    fi.Attributes = fi.Attributes & ~FileAttributes.ReadOnly;
                }
            }
            // 写同目录临时文件（保证原子替换）
            var tmp = file + ".tmp." + Guid.NewGuid().ToString("N") + ".part";
            using(var fs = new FileStream(tmp, FileMode.CreateNew, FileAccess.Write, FileShare.None, 4096, FileOptions.WriteThrough)) {
                var b = Encoding.UTF8.GetBytes(json);
                fs.Write(b, 0, b.Length);
                fs.Flush(true);
            }
            // 原子替换：Windows下Replace相当于原子操作
            if(File.Exists(file)) {
                File.Replace(tmp, file, null);
            } else {
                File.Move(tmp, file);
            }
            return true;
        } catch(Exception e) {
            err = e.GetType().Name + ": " + e.Message;
            return false;
        }
    }
}

class Program {
    static string Root;

    static void Main() {
        Root = Path.Combine(Path.GetTempPath(), "hh_write_test_" + Guid.NewGuid().ToString("N").Substring(0,8));
        Directory.CreateDirectory(Root);
        Console.WriteLine("=== Test Root: {0} ===", Root);

        TestOld();  // RED
        Console.WriteLine();
        TestNew();  // GREEN

        Console.WriteLine("\n=== TOTAL: PASS={0} FAIL={1} ===", Logger.Pass, Logger.Fail);
        try { Directory.Delete(Root, true); } catch {}
        Environment.Exit(Logger.Fail > 0 ? 1 : 0);
    }

    static void TestOld() {
        Console.WriteLine("\n[OLD Writer - RED Phase] 当前实现(file_put_contents + LOCK_EX)");
        int baseFail = Logger.Fail;

        // T1 正常写入
        string f1 = Path.Combine(Root, "o1.json");
        string e;
        bool ok = OldWriter.Write(f1, "[{\"a\":1}]", out e);
        Logger.Check("T1 正常写入返回true", ok, e);
        Logger.Check("T1 内容完整", File.ReadAllText(f1, Encoding.UTF8) == "[{\"a\":1}]");

        // T2 只读文件
        string f2 = Path.Combine(Root, "o2.json");
        string orig = "{\"x\":1}";
        OldWriter.Write(f2, orig, out _);
        new FileInfo(f2).IsReadOnly = true;
        ok = OldWriter.Write(f2, "{\"x\":2}", out e);
        Logger.Check("T2 只读写入返回false", ok == false, $"ok={ok} err={e}");
        string actual = File.ReadAllText(f2, Encoding.UTF8);
        Logger.Check("T2 内容不可被截断(原子性)", actual == orig, $"orig={orig} actual={actual}");
        new FileInfo(f2).IsReadOnly = false;

        // T3 并发写入
        string f3 = Path.Combine(Root, "o3.json");
        RunConcurrent(f3, useNew: false);
        string c = File.ReadAllText(f3, Encoding.UTF8);
        bool valid = IsValidJson(c);
        Logger.Check("T3 并发后JSON合法", valid, $"len={c.Length} head={Head(c,120)}");

        // T4 父目录不存在
        string f4 = Path.Combine(Root, "subA", "nested", "o4.json");
        ok = OldWriter.Write(f4, "[1,2,3]", out e);
        Logger.Check("T4 父目录不存在返回false(当前实现无兜底)", ok == false, $"ok={ok} err={e}");

        Console.WriteLine("  OLD Phase fails: {0}", Logger.Fail - baseFail);
    }

    static void TestNew() {
        Console.WriteLine("\n[NEW Writer - GREEN Phase] 改进实现(临时文件+原子替换)");
        int baseFail = Logger.Fail;

        // T1 正常写入
        string f1 = Path.Combine(Root, "n1.json");
        string e;
        bool ok = NewWriter.Write(f1, "[{\"a\":1}]", out e);
        Logger.Check("T1 正常写入返回true", ok, e);
        Logger.Check("T1 内容完整", File.ReadAllText(f1, Encoding.UTF8) == "[{\"a\":1}]");

        // T2 只读文件：应写入成功（自动清只读属性）
        string f2 = Path.Combine(Root, "n2.json");
        string orig = "{\"x\":1}";
        NewWriter.Write(f2, orig, out _);
        new FileInfo(f2).IsReadOnly = true;
        ok = NewWriter.Write(f2, "{\"x\":2}", out e);
        Logger.Check("T2 只读文件写入成功(自动清ReadOnly)", ok == true, $"ok={ok} err={e}");
        string actual = File.ReadAllText(f2, Encoding.UTF8);
        Logger.Check("T2 内容更新为新值", actual == "{\"x\":2}", $"actual={actual}");
        new FileInfo(f2).IsReadOnly = false;

        // T3 并发写入
        string f3 = Path.Combine(Root, "n3.json");
        RunConcurrent(f3, useNew: true);
        string c = File.ReadAllText(f3, Encoding.UTF8);
        bool valid = IsValidJson(c);
        Logger.Check("T3 并发后JSON合法(原子替换)", valid, $"len={c.Length} head={Head(c,120)}");

        // T4 父目录不存在：应自动创建+写入成功
        string f4 = Path.Combine(Root, "subB", "nested-deep", "n4.json");
        ok = NewWriter.Write(f4, "[1,2,3]", out e);
        Logger.Check("T4 父目录不存在→自动创建并写入成功", ok == true, $"ok={ok} err={e}");
        if(ok) Logger.Check("T4 内容正确", File.ReadAllText(f4, Encoding.UTF8) == "[1,2,3]");

        // T5 大文件写入
        string f5 = Path.Combine(Root, "n5.json");
        string big = "[" + string.Join(",", Enumerable.Range(0,500).Select(i => $"{\"\\\"}\\\"item_{i}\\\\\":\\\"" + new string('x', 200) + "\\\"")) + "]";
        ok = NewWriter.Write(f5, big, out e);
        Logger.Check("T5 100KB大文件写入成功", ok, e);
        if(ok) {
            string r = File.ReadAllText(f5, Encoding.UTF8);
            Logger.Check("T5 内容一致", r == big);
            Logger.Check("T5 JSON合法", IsValidJson(r));
        }

        Console.WriteLine("  NEW Phase fails: {0}", Logger.Fail - baseFail);
    }

    // 并发：8进程 x 20次写入
    static void RunConcurrent(string path, bool useNew) {
        File.WriteAllText(path, "[]", Encoding.UTF8);
        var procs = new List<Process>();
        string selfExe = Process.GetCurrentProcess().MainModule.FileName;
        for(int i = 1; i <= 8; i++) {
            var psi = new ProcessStartInfo {
                FileName = selfExe,
                Arguments = $"__worker__ {(useNew?1:0)} \"{path}\" {i}",
                UseShellExecute = false,
                CreateNoWindow = true
            };
            procs.Add(Process.Start(psi));
        }
        foreach(var p in procs) { p.WaitForExit(30000); }
    }

    // Worker模式入口（并发子进程）
    public static void Worker(string[] args) {
        bool useNew = args[1] == "1";
        string path = args[2];
        int id = int.Parse(args[3]);
        var rnd = new Random(id);
        for(int i = 0; i < 20; i++) {
            string longStr = new string('a' + (char)(id % 26), 300);
            string json = $"[{{\"worker\":{id},\"i\":{i},\"ts\":{DateTime.UtcNow.Ticks},\"payload\":\"{longStr}\"}}]";
            string e;
            if(useNew) NewWriter.Write(path, json, out e);
            else OldWriter.Write(path, json, out e);
            Thread.Sleep(rnd.Next(5, 25));
        }
    }

    static bool IsValidJson(string s) {
        if(string.IsNullOrWhiteSpace(s)) return false;
        try {
            // 简单验证：括号计数 & System.Text.Json解析
            System.Text.Json.Nodes.JsonNode.Parse(s);
            return true;
        } catch { return false; }
    }

    static string Head(string s, int n) {
        if(string.IsNullOrEmpty(s)) return "(empty)";
        return s.Substring(0, Math.Min(n, s.Length));
    }
}
