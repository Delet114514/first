$File = 'd:\桌面\网站项目\收录\data\submissions.json'
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
$raw = [System.IO.File]::ReadAllText($File, $utf8NoBom)
$list = @()
if ($raw -and $raw.Trim().Length -gt 0) {
  $ser = New-Object System.Web.Script.Serialization.JavaScriptSerializer
  $ser.MaxJsonLength = [int]::MaxValue
  $obj = $ser.DeserializeObject($raw)
  if ($obj -is [System.Collections.ArrayList]) {
    foreach ($o in $obj) { $list += $o }
  } elseif ($obj -is [Array]) {
    foreach ($o in $obj) { $list += $o }
  } elseif ($obj -is [object[]]) {
    foreach ($o in $obj) { $list += $o }
  }
}
$now = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
$sid = '20260830' + (Get-Random -Minimum 100000000 -Maximum 999999999).ToString()
$newEntry = New-Object 'System.Collections.Generic.Dictionary[string,object]'
$newEntry['id'] = $sid
$newEntry['email'] = 'e2e_admin@hh.com'
$newEntry['wechat'] = 'wx_e2e'
$newEntry['category'] = 'server'
$newEntry['name'] = '[E2E] 阿里云CDN分发节点'
$newEntry['description'] = 'Global accel CN2 GIA / anti-DDoS / pay-as-you-go'
$newEntry['link'] = 'https://cdn-e2e.example.cn'
$newEntry['status'] = 'approved'
$newEntry['submitted_at'] = $now
$newEntry['reviewed_at'] = $now
$newEntry['review_note'] = 'auto e2e seed'
$newEntry['reviewer'] = 'admin'
$newEntry['hidden'] = $false
$arrlist = New-Object 'System.Collections.ArrayList'
foreach ($x in $list) { [void]$arrlist.Add($x) }
[void]$arrlist.Add($newEntry)
$ser2 = New-Object System.Web.Script.Serialization.JavaScriptSerializer
$ser2.MaxJsonLength = [int]::MaxValue
$json = $ser2.Serialize($arrlist)
$tmp = $File + '.tmp'
[System.IO.File]::WriteAllText($tmp, $json, $utf8NoBom)
[System.IO.File]::Replace($tmp, $File, $null)
Write-Host ('Written submission id=' + $sid + ' total=' + $arrlist.Count + ' bytes=' + (Get-Item -LiteralPath $File).Length)
